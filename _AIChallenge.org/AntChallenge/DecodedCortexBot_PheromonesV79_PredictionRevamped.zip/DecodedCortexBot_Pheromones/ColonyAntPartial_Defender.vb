﻿Public Partial Class ColonyAnt

    Private Function GetAntHillDefenderMoveDirection() As Direction
        Dim MoveDirection As Direction

        If MovementController.GivenCombatOrder
            MoveDirection = MovementController.GetCombatOrderDirection 
            MovementController.ResetCombatOrder
        ElseIf MovementController.NearAlert
            MoveDirection = MovementController.GoTowardAlert
        ElseIf MovementController.NearDefenderPosition
            MoveDirection = MovementController.GoTowardClosestDefenderPosition
        End If

        Return MoveDirection
    End Function

    'Private Function GetAntHillDefenderMoveDirection2() As Direction
    '    Dim MoveDirection As Direction

    '    If MovementController.GivenCombatOrder
    '        MoveDirection = MovementController.GetCombatOrderDirection 
    '        MovementController.ResetCombatOrder
    '    ElseIf MovementController.NearAlert
    '        MoveDirection = MovementController.GoTowardAlert
    '    Else
    '        If DefenderReturnToAntHill
    '            'MoveDirection = MovementController.GoTowardMyAntHill
    '            'MsgBox("GoTowardMyAntHill:" & MoveDirection)
    '        Else
    '            MoveDirection = MovementController.GoAwayFromMyAntPersistentPheromone
    '            'MsgBox("GoAwayMyAntHill:" & MoveDirection)
    '        End If
    '    End If

    '    'Logic to tell the ant how to walk back and forth...
    '    Dim MaxMyAntHill As Integer = MovementController.GetMaxMyAntHillStrength
    '    If Not MovementController.NearMyAntHill(MaxMyAntHill-6)
    '    'If Not MovementController.NearMyAntHill
    '        'If the ant is almost at the edge of my ant hill's strength values, turn around and go back towards my ant hill
    '        DefenderReturnToAntHill = True
    '    ElseIf MovementController.NearMyAntHill(2)
    '        'If the ant is within 2 spaces of my ant hill, time to turn around and walk away again
    '        DefenderReturnToAntHill = False
    '    End If

    '    'It is entirely possible that combat orders may actually take a defender ant off the ant hill strength values, if this happens,
    '    'Then turn this ant into an explorer ant so that it does not get stuck
    '    Dim AdjTileHasStrengthValue As Boolean = False
    '    For Each AdjTile As MapTile In CurrentMapTile.LinkedTiles
    '        If AdjTile.MyAntHillStrength > 0 Then
    '            AdjTileHasStrengthValue = True
    '        End If
    '    Next
    '    If Not AdjTileHasStrengthValue
    '        'MsgBox("Defender ant now an explorer ant!")
    '        Mission = ColonyAntMission.Explorer
    '    End If

    '    Return MoveDirection
    'End Function
End Class
