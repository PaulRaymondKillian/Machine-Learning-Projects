﻿Option Strict On

Imports System.Collections.Generic

Public Partial Class ColonyAntMovementController

#Region "Alert"

    Private Function ChooseHighestNonOccupiedAdjacentAlertStrengthDirection() As Direction Implements IColonyAntMovementController.GoTowardAlert
        Dim MoveDirection As Direction
        'Determine highest food strength value for inputted food item ID of all adjacent tiles
        Dim HighestAlertStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
        Dim HighestAlertStrengthValue As Integer = Integer.MinValue
        For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
            If MapTile.AlertStrength >= HighestAlertStrengthValue AndAlso MapTile.AntHere = False Then
                HighestAlertStrengthValue = MapTile.AlertStrength
                HighestAlertStrengthMapTile = MapTile
            End If
        Next

        'Determine what direction we must move to go to this tile
        For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
            If CurrentMapTile.LinkedTiles(i).Equals(HighestAlertStrengthMapTile) Then
                MoveDirection = CType(i, Direction)
                Exit For
            End If
        Next
        Return MoveDirection
    End Function

    'Private Function ChooseHighestAdjacentAlertStrengthDirection() As Direction
    '    Dim MoveDirection As Direction
    '    'Determine highest food strength value for inputted food item ID of all adjacent tiles
    '    Dim HighestAlertStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
    '    Dim HighestAlertStrengthValue As Integer = Integer.MinValue
    '    For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '        If MapTile.AlertStrength >= HighestAlertStrengthValue Then
    '            HighestAlertStrengthValue = MapTile.AlertStrength
    '            HighestAlertStrengthMapTile = MapTile
    '        End If
    '    Next

    '    'Determine what direction we must move to go to this tile
    '    For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '        If CurrentMapTile.LinkedTiles(i).Equals(HighestAlertStrengthMapTile) Then
    '            MoveDirection = CType(i, Direction)
    '            Exit For
    '        End If
    '    Next
    '    Return MoveDirection
    'End Function

#End Region

#Region "Food"

    Public Function GoTowardClosestFood() As Direction Implements IColonyAntMovementController.GoTowardClosestFood
        Dim MoveDirection As Direction
        Dim HighestFoodID As String
        
        HighestFoodID = GetHighestAdjacentFoodStrengthValue()
        MoveDirection = ChooseHighestAdjacentFoodItemStrengthDirection(HighestFoodID)
        
        Return MoveDirection
    End Function

    Private Function ChooseHighestAdjacentFoodItemStrengthDirection(pHighestStrengthID As String) As Direction
        Dim MoveDirection As Direction
        'Determine highest food strength value for inputted food item ID of all adjacent tiles
        Dim HighestFoodStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
        Dim HighestFoodStrengthValue As Integer = Integer.MinValue
        For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
            If CInt(MapTile.FoodStrengthHash(pHighestStrengthID)) >= HighestFoodStrengthValue Then
                HighestFoodStrengthValue = CInt(MapTile.FoodStrengthHash(pHighestStrengthID))
                HighestFoodStrengthMapTile = MapTile
            End If
        Next

        'Determine what direction we must move to go to this tile
        For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
            If CurrentMapTile.LinkedTiles(i).Equals(HighestFoodStrengthMapTile) Then
                MoveDirection = CType(i, Direction)
                Exit For
            End If
        Next
        Return MoveDirection
    End Function

    Private Function GetHighestAdjacentFoodStrengthValue() As String
        'Find the highest food strength value
        Dim HighestStrengthValue As Integer = Integer.MinValue
        Dim HighestStrengthID As String = ""
        For Each FoodStrengthItemID As String In CurrentMapTile.FoodStrengthHash.Keys
            If HighestStrengthValue < CInt(CurrentMapTile.FoodStrengthHash(FoodStrengthItemID)) Then
                HighestStrengthValue = CInt(CurrentMapTile.FoodStrengthHash(FoodStrengthItemID))
                HighestStrengthID = FoodStrengthItemID
            End If
        Next
        Return HighestStrengthID
    End Function

#End Region

#Region "My Ant Hill"

    Private Function ChooseHighestNonOccupiedAdjacentMyAntHillStrengthDirection() As Direction Implements IColonyAntMovementController.GoTowardMyAntHill
        Dim MoveDirection As Direction
        'Determine highest food strength value for inputted food item ID of all adjacent tiles
        Dim HighestMyAntHillStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
        Dim HighestMyAntHillStrengthValue As Integer = Integer.MinValue
        For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
            If MapTile.MyAntHillStrength >= HighestMyAntHillStrengthValue AndAlso MapTile.AntHere = False Then
                HighestMyAntHillStrengthValue = MapTile.AlertStrength
                HighestMyAntHillStrengthMapTile = MapTile
            End If
        Next

        'Determine what direction we must move to go to this tile
        For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
            If CurrentMapTile.LinkedTiles(i).Equals(HighestMyAntHillStrengthMapTile) Then
                MoveDirection = CType(i, Direction)
                Exit For
            End If
        Next
        Return MoveDirection
    End Function

    'Private Function ChooseHighestAdjacentAlertStrengthDirection() As Direction
    '    Dim MoveDirection As Direction
    '    'Determine highest food strength value for inputted food item ID of all adjacent tiles
    '    Dim HighestAlertStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
    '    Dim HighestAlertStrengthValue As Integer = Integer.MinValue
    '    For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '        If MapTile.AlertStrength >= HighestAlertStrengthValue Then
    '            HighestAlertStrengthValue = MapTile.AlertStrength
    '            HighestAlertStrengthMapTile = MapTile
    '        End If
    '    Next

    '    'Determine what direction we must move to go to this tile
    '    For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '        If CurrentMapTile.LinkedTiles(i).Equals(HighestAlertStrengthMapTile) Then
    '            MoveDirection = CType(i, Direction)
    '            Exit For
    '        End If
    '    Next
    '    Return MoveDirection
    'End Function

#End Region


#Region "Enemy Ant Hill"

    Public Function GoTowardClosestEnemyAntHill() As Direction Implements IColonyAntMovementController.GoTowardClosestEnemyAntHill
        Dim MoveDirection As Direction
        Dim HighestEnemyAntHillID As String
        
        HighestEnemyAntHillID = GetHighestAdjacentEnemyAntHillStrengthValue
        MoveDirection = ChooseHighestNonOccupiedAdjacentEnemyAntHillStrengthDirection(HighestEnemyAntHillID)
        
        Return MoveDirection
    End Function

    'Private Function ChooseHighestAdjacentEnemyAntHillStrengthDirection(pHighestStrengthID As String) As Direction
    '    Dim MoveDirection As Direction
    '    'Determine highest food strength value for inputted food item ID of all adjacent tiles
    '    Dim HighestEnemyAntHillStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
    '    Dim HighestEnemyAntHillStrengthValue As Integer = Integer.MinValue
    '    For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '        If CInt(MapTile.EnemyAntHillStrengthHash(pHighestStrengthID)) >= HighestEnemyAntHillStrengthValue Then
    '            HighestEnemyAntHillStrengthValue = CInt(MapTile.EnemyAntHillStrengthHash(pHighestStrengthID))
    '            HighestEnemyAntHillStrengthMapTile = MapTile
    '        End If
    '    Next

    '    'Determine what direction we must move to go to this tile
    '    For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '        If CurrentMapTile.LinkedTiles(i).Equals(HighestEnemyAntHillStrengthMapTile) Then
    '            MoveDirection = CType(i, Direction)
    '            Exit For
    '        End If
    '    Next
    '    Return MoveDirection
    'End Function

    Private Function ChooseHighestNonOccupiedAdjacentEnemyAntHillStrengthDirection(pHighestStrengthID As String) As Direction
        Dim MoveDirection As Direction
        'Determine highest food strength value for inputted food item ID of all adjacent tiles
        Dim HighestEnemyAntHillStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
        Dim HighestEnemyAntHillStrengthValue As Integer = Integer.MinValue
        For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
            If CInt(MapTile.EnemyAntHillStrengthHash(pHighestStrengthID)) >= HighestEnemyAntHillStrengthValue AndAlso MapTile.AntHere = False Then
                HighestEnemyAntHillStrengthValue = CInt(MapTile.EnemyAntHillStrengthHash(pHighestStrengthID))
                HighestEnemyAntHillStrengthMapTile = MapTile
            End If
        Next

        'Determine what direction we must move to go to this tile
        For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
            If CurrentMapTile.LinkedTiles(i).Equals(HighestEnemyAntHillStrengthMapTile) Then
                MoveDirection = CType(i, Direction)
                Exit For
            End If
        Next
        Return MoveDirection
    End Function

    Private Function GetHighestAdjacentEnemyAntHillStrengthValue() As String
        'Find the highest food strength value
        Dim HighestStrengthValue As Integer = Integer.MinValue
        Dim HighestStrengthID As String = ""
        For Each EnemyAntHillStrengthItemID As String In CurrentMapTile.EnemyAntHillStrengthHash.Keys
            If HighestStrengthValue < CInt(CurrentMapTile.EnemyAntHillStrengthHash(EnemyAntHillStrengthItemID)) Then
                HighestStrengthValue = CInt(CurrentMapTile.EnemyAntHillStrengthHash(EnemyAntHillStrengthItemID))
                HighestStrengthID = EnemyAntHillStrengthItemID
            End If
        Next
        Return HighestStrengthID
    End Function

#End Region

#Region "Closest Enemy Ant"

#End Region

#Region "Enemy Ants Pheromone - Towards"

    'Private Function ChooseHighestAdjacentEnemyAntPheromoneStrengthDirection() As Direction
    '    Dim MoveDirection As Direction
    '    'Determine highest food strength value for inputted food item ID of all adjacent tiles
    '    Dim HighestEnemyAntPheromoneStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
    '    Dim HighestEnemyAntPheromoneStrengthValue As Integer = Integer.MinValue
    '    For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '        If MapTile.EnemyAntPheromoneStrength >= HighestEnemyAntPheromoneStrengthValue Then
    '            HighestEnemyAntPheromoneStrengthValue = MapTile.EnemyAntPheromoneStrength
    '            HighestEnemyAntPheromoneStrengthMapTile = MapTile
    '        End If
    '    Next

    '    'Determine what direction we must move to go to this tile
    '    For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '        If CurrentMapTile.LinkedTiles(i).Equals(HighestEnemyAntPheromoneStrengthMapTile) Then
    '            MoveDirection = CType(i, Direction)
    '            Exit For
    '        End If
    '    Next
    '    Return MoveDirection
    'End Function

    'Private Function ChooseHighestNonOccupiedAdjacentEnemyAntPheromoneStrengthDirection() As Direction Implements IColonyAntMovementController.GoTowardEnemyAnts
    '    Dim MoveDirection As Direction
    '    'Determine highest food strength value for inputted food item ID of all adjacent tiles
    '    Dim HighestEnemyAntPheromoneStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
    '    Dim HighestEnemyAntPheromoneStrengthValue As Integer = Integer.MinValue
    '    For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '        If MapTile.EnemyAntPheromoneStrength >= HighestEnemyAntPheromoneStrengthValue AndAlso MapTile.AntHere = False Then
    '            HighestEnemyAntPheromoneStrengthValue = MapTile.EnemyAntPheromoneStrength
    '            HighestEnemyAntPheromoneStrengthMapTile = MapTile
    '        End If
    '    Next

    '    'Determine what direction we must move to go to this tile
    '    For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '        If CurrentMapTile.LinkedTiles(i).Equals(HighestEnemyAntPheromoneStrengthMapTile) Then
    '            MoveDirection = CType(i, Direction)
    '            Exit For
    '        End If
    '    Next
    '    Return MoveDirection
    'End Function

    Public Function GoTowardsEnemyAntPheromone() As Direction Implements IColonyAntMovementController.GoTowardClosestEnemyAnt
        Dim MoveDirection As Direction
        Dim HighestEnemyAntPheroID As String

        HighestEnemyAntPheroID = GetHighestAdjacentEnemyAntPheromoneStrengthValue()
        MoveDirection = ChooseHighestNonOccupiedAdjacentEnemyAntPheromoneStrengthDirection(HighestEnemyAntPheroID)
        
        Return MoveDirection
    End Function

    Private Function ChooseHighestNonOccupiedAdjacentEnemyAntPheromoneStrengthDirection(pHighestStrengthID As String) As Direction
        Dim MoveDirection As Direction
        'Determine highest food strength value for inputted food item ID of all adjacent tiles
        Dim HighestEnemyAntPheroStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
        Dim HighestEnemyAntPheroStrengthValue As Integer = Integer.MinValue
        For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
            If CInt(MapTile.EnemyAntPheromoneStrengthHash(pHighestStrengthID)) >= HighestEnemyAntPheroStrengthValue Then
                HighestEnemyAntPheroStrengthValue = CInt(MapTile.EnemyAntPheromoneStrengthHash(pHighestStrengthID))
                HighestEnemyAntPheroStrengthMapTile = MapTile
            End If
        Next

        'Determine what direction we must move to go to this tile
        For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
            If CurrentMapTile.LinkedTiles(i).Equals(HighestEnemyAntPheroStrengthMapTile) Then
                MoveDirection = CType(i, Direction)
                Exit For
            End If
        Next
        Return MoveDirection
    End Function

    Private Function GetHighestAdjacentEnemyAntPheromoneStrengthValue() As String
        'Find the highest food strength value
        Dim HighestStrengthValue As Integer = Integer.MinValue
        Dim HighestStrengthID As String = ""
        For Each EnemyAntPheroStrengthItemID As String In CurrentMapTile.EnemyAntPheromoneStrengthHash.Keys
            If HighestStrengthValue < CInt(CurrentMapTile.EnemyAntPheromoneStrengthHash(EnemyAntPheroStrengthItemID)) Then
                HighestStrengthValue = CInt(CurrentMapTile.EnemyAntPheromoneStrengthHash(EnemyAntPheroStrengthItemID))
                HighestStrengthID = EnemyAntPheroStrengthItemID
            End If
        Next
        Return HighestStrengthID
    End Function

#End Region

#Region "Enemy Ants Pheromone - Away"

#End Region

#Region "My Ant Immediate Pheromone - Towards"

    Public Function GoTowardsMyAntImmediatePheromone() As Direction Implements IColonyAntMovementController.GoTowardMyAntImmediatePheromone
        Dim MoveDirection As Direction
        Dim HighestMyAntImmPheroID As String

        HighestMyAntImmPheroID = GetHighestAdjacentMyAntImmediatePheromoneStrengthValue()
        MoveDirection = ChooseHighestNonOccupiedAdjacentMyAntImmediatePheromoneStrengthDirection(HighestMyAntImmPheroID)
        
        Return MoveDirection
    End Function


    Private Function ChooseHighestNonOccupiedAdjacentMyAntImmediatePheromoneStrengthDirection(pHighestStrengthID As String) As Direction
        Dim MoveDirection As Direction
        'Determine highest food strength value for inputted food item ID of all adjacent tiles
        Dim HighestMyAntImmPheroStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
        Dim HighestMyAntImmPheroStrengthValue As Integer = Integer.MinValue
        For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
            If CInt(MapTile.MyAntImmediatePheromoneStrengthHash(pHighestStrengthID)) >= HighestMyAntImmPheroStrengthValue Then
                HighestMyAntImmPheroStrengthValue = CInt(MapTile.MyAntImmediatePheromoneStrengthHash(pHighestStrengthID))
                HighestMyAntImmPheroStrengthMapTile = MapTile
            End If
        Next

        'Determine what direction we must move to go to this tile
        For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
            If CurrentMapTile.LinkedTiles(i).Equals(HighestMyAntImmPheroStrengthMapTile) Then
                MoveDirection = CType(i, Direction)
                Exit For
            End If
        Next
        Return MoveDirection
    End Function

    Private Function GetHighestAdjacentMyAntImmediatePheromoneStrengthValue() As String
        'Find the highest food strength value
        Dim HighestStrengthValue As Integer = Integer.MinValue
        Dim HighestStrengthID As String = ""
        For Each MyAntImmPheroStrengthItemID As String In CurrentMapTile.MyAntImmediatePheromoneStrengthHash.Keys
            If HighestStrengthValue < CInt(CurrentMapTile.MyAntImmediatePheromoneStrengthHash(MyAntImmPheroStrengthItemID)) Then
                HighestStrengthValue = CInt(CurrentMapTile.MyAntImmediatePheromoneStrengthHash(MyAntImmPheroStrengthItemID))
                HighestStrengthID = MyAntImmPheroStrengthItemID
            End If
        Next
        Return HighestStrengthID
    End Function


    'Private Function ChooseHighestAdjacentMyAntImmediatePheromoneStrengthDirection() As Direction
    '    Dim MoveDirection As Direction
    '    'Determine highest food strength value for inputted food item ID of all adjacent tiles
    '    Dim HighestMyAntImmediatePheromoneStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
    '    Dim HighestMyAntImmediatePheromoneStrengthValue As Integer = Integer.MinValue
    '    For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '        If MapTile.MyAntImmediatePheromoneStrength >= HighestMyAntImmediatePheromoneStrengthValue Then
    '            HighestMyAntImmediatePheromoneStrengthValue = MapTile.MyAntImmediatePheromoneStrength
    '            HighestMyAntImmediatePheromoneStrengthMapTile = MapTile
    '        End If
    '    Next

    '    'Determine what direction we must move to go to this tile
    '    For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '        If CurrentMapTile.LinkedTiles(i).Equals(HighestMyAntImmediatePheromoneStrengthMapTile) Then
    '            MoveDirection = CType(i, Direction)
    '            Exit For
    '        End If
    '    Next
    '    Return MoveDirection
    'End Function


    'Private Function ChooseHighestNonOccupiedAdjacentMyAntImmediatePheromoneStrengthDirection() As Direction
    '    Dim MoveDirection As Direction
    '    'Determine highest food strength value for inputted food item ID of all adjacent tiles
    '    Dim HighestMyAntImmediatePheromoneStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
    '    Dim HighestMyAntImmediatePheromoneStrengthValue As Integer = Integer.MinValue
    '    For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '        If MapTile.MyAntImmediatePheromoneStrength >= HighestMyAntImmediatePheromoneStrengthValue AndAlso MapTile.AntHere = False Then
    '            HighestMyAntImmediatePheromoneStrengthValue = MapTile.MyAntImmediatePheromoneStrength
    '            HighestMyAntImmediatePheromoneStrengthMapTile = MapTile
    '        End If
    '    Next

    '    'Determine what direction we must move to go to this tile
    '    For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '        If CurrentMapTile.LinkedTiles(i).Equals(HighestMyAntImmediatePheromoneStrengthMapTile) Then
    '            MoveDirection = CType(i, Direction)
    '            Exit For
    '        End If
    '    Next
    '    Return MoveDirection
    'End Function

#End Region

#Region "My Ant Immediate Pheromone - Away"

    'Public Function GoAwayFromMyAntImmediatePheromone() As Direction Implements IColonyAntMovementController.GoAwayFromMyAntImmediatePheromone
    '    Dim MoveDirection As Direction
    '    Dim HighestMyAntImmediatePheromoneValue As Integer
        
    '    HighestMyAntImmediatePheromoneValue = GetLowestAdjacentMyAntImmediatePheromoneStrengthValue
    '    MoveDirection = ChooseLowestNonOccupiedAdjacentMyAntImmediatePheromoneStrengthDirection(HighestMyAntImmediatePheromoneValue)
        
    '    Return MoveDirection
    'End Function

    'Private Function ChooseLowestAdjacentMyAntImmediatePheromoneStrengthDirection(pLowestStrengthValue As Integer) As Direction
    '    Dim MoveDirection As Direction
    '    If pLowestStrengthValue = -1
    '        'There is no valid move... set move direction to north just because... prevents null ref 
    '        MoveDirection = Direction.n
    '    Else
    
    '        'Create list of all map tiles with the lowest MyAntHill Strength (may be multiple tiles)
    '        Dim LowestMapTiles As New List(Of MapTile)

    '        Try
    '            For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '                If MapTile.GetMyAntImmediatePheromoneStrength = pLowestStrengthValue Then
    '                    LowestMapTiles.Add(MapTile)
    '                End If
    '            Next

    '        Catch ex As Exception
    '            Throw New Exception("Error in 1 - " & ex.Message)
    '        End Try

    '        'Now we have a list of lowest adjacent map tiles. Choose one randomly.
    '        Dim ChosenAdjacentMapTile As MapTile
    '        Try

    '            If LowestMapTiles.Count > 0
    '                ChosenAdjacentMapTile = LowestMapTiles(_Random.Next Mod LowestMapTiles.Count)
    '            Else
    '                Throw New Exception("Lowest Map Tiles Count = 0!!!!, " & _ 
    '                                    "LowestStrengthValue=" & pLowestStrengthValue & ", " & _
    '                                    "CountLinkedTiles=" & CurrentMapTile.LinkedTiles.Length & ", " & _
    '                                    "0= " & CurrentMapTile.LinkedTiles(0).GetMyAntImmediatePheromoneStrength & ", " & _
    '                                    "1= " & CurrentMapTile.LinkedTiles(1).GetMyAntImmediatePheromoneStrength & ", " & _
    '                                    "2= " & CurrentMapTile.LinkedTiles(2).GetMyAntImmediatePheromoneStrength & ", " & _
    '                                    "3= " & CurrentMapTile.LinkedTiles(3).GetMyAntImmediatePheromoneStrength & ", ")
    '            End If
    '        Catch ex As Exception
    '            Throw New Exception("Error in ChooseLowestAdjacentMyAntPheromoneStrengthDirection - " & ex.Message)
    '        End Try

    '        Try

    '            'Determine what direction we must move to go to this tile
    '            For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '                If CurrentMapTile.LinkedTiles(i).Equals(ChosenAdjacentMapTile) Then
    '                    MoveDirection = CType(i, Direction)
    '                    Exit For
    '                End If
    '            Next
    '        Catch ex As Exception
    '            Throw New Exception("Error in 3 - " & ex.Message)
    '        End Try
    '    End If
    '    Return MoveDirection
    'End Function

    'Private Function ChooseLowestNonOccupiedAdjacentMyAntImmediatePheromoneStrengthDirection(pLowestStrengthValue As Integer) As Direction
    '    Dim MoveDirection As Direction
    '    If pLowestStrengthValue = -1
    '        'There is no valid move... set move direction to north just because... prevents null ref 
    '        MoveDirection = Direction.n
    '    Else
    
    '        'Create list of all map tiles with the lowest MyAntHill Strength (may be multiple tiles)
    '        Dim LowestMapTiles As New List(Of MapTile)

    '        Try
    '            For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '                If MapTile.GetMyAntImmediatePheromoneStrength = pLowestStrengthValue AndAlso MapTile.AntHere = False Then
    '                    LowestMapTiles.Add(MapTile)
    '                End If
    '            Next

    '        Catch ex As Exception
    '            Throw New Exception("Error in 1 - " & ex.Message)
    '        End Try

    '        'Now we have a list of lowest adjacent map tiles. Choose one randomly.
    '        Dim ChosenAdjacentMapTile As MapTile
    '        Try

    '            If LowestMapTiles.Count > 0
    '                ChosenAdjacentMapTile = LowestMapTiles(_Random.Next Mod LowestMapTiles.Count)
    '            Else
    '                Throw New Exception("Lowest Map Tiles Count = 0!!!!, " & _ 
    '                                    "LowestStrengthValue=" & pLowestStrengthValue & ", " & _
    '                                    "CountLinkedTiles=" & CurrentMapTile.LinkedTiles.Length & ", " & _
    '                                    "0= " & CurrentMapTile.LinkedTiles(0).GetMyAntImmediatePheromoneStrength & ", " & _
    '                                    "1= " & CurrentMapTile.LinkedTiles(1).GetMyAntImmediatePheromoneStrength & ", " & _
    '                                    "2= " & CurrentMapTile.LinkedTiles(2).GetMyAntImmediatePheromoneStrength & ", " & _
    '                                    "3= " & CurrentMapTile.LinkedTiles(3).GetMyAntImmediatePheromoneStrength & ", ")
    '            End If
    '        Catch ex As Exception
    '            Throw New Exception("Error in ChooseLowestAdjacentMyAntPheromoneStrengthDirection - " & ex.Message)
    '        End Try

    '        Try

    '            'Determine what direction we must move to go to this tile
    '            For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '                If CurrentMapTile.LinkedTiles(i).Equals(ChosenAdjacentMapTile) Then
    '                    MoveDirection = CType(i, Direction)
    '                    Exit For
    '                End If
    '            Next
    '        Catch ex As Exception
    '            Throw New Exception("Error in 3 - " & ex.Message)
    '        End Try
    '    End If
    '    Return MoveDirection
    'End Function

    'Private Function GetLowestAdjacentMyAntImmediatePheromoneStrengthValue() As Integer
    '    'Find the lowest MyAntHill Strength of all adjacent tiles
    '    Dim LowestStrengthValue As Integer = Integer.MaxValue
    '    For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '        If MapTile.GetMyAntImmediatePheromoneStrength < LowestStrengthValue And MapTile.Passable And MapTile.AntHere = False Then
    '            LowestStrengthValue = MapTile.GetMyAntImmediatePheromoneStrength
    '        End If
    '    Next


    '    If LowestStrengthValue = Integer.MaxValue
    '        LowestStrengthValue = -1
    '        'Throw New Exception("LowestStrengthValue=" & LowestStrengthValue & ", " & _ 
    '        '                    "Linked(0)=" & CurrentMapTile.LinkedTiles(0).GetMyAntHillStrength & "-" & CurrentMapTile.LinkedTiles(0).Passable & ", " & _
    '        '                    "Linked(1)=" & CurrentMapTile.LinkedTiles(1).GetMyAntHillStrength & "-" & CurrentMapTile.LinkedTiles(1).Passable & ", " & _
    '        '                    "Linked(2)=" & CurrentMapTile.LinkedTiles(2).GetMyAntHillStrength & "-" & CurrentMapTile.LinkedTiles(2).Passable & ", " & _
    '        '                    "Linked(3)=" & CurrentMapTile.LinkedTiles(3).GetMyAntHillStrength & "-" & CurrentMapTile.LinkedTiles(3).Passable & ", ")
    '    End If



    '    Return LowestStrengthValue
    'End Function

#End Region

#Region "My Ant Persistent - Towards"

    'Private Function ChooseHighestAdjacentMyAntPersistentPheromoneStrengthDirection() As Direction
    '    Dim MoveDirection As Direction
    '    'Determine highest food strength value for inputted food item ID of all adjacent tiles
    '    Dim HighestMyAntPersistentPheromoneStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
    '    Dim HighestMyAntPersistentPheromoneStrengthValue As Integer = Integer.MinValue
    '    For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '        If MapTile.MyAntPersistentPheromoneStrength >= HighestMyAntPersistentPheromoneStrengthValue Then
    '            HighestMyAntPersistentPheromoneStrengthValue = MapTile.MyAntPersistentPheromoneStrength
    '            HighestMyAntPersistentPheromoneStrengthMapTile = MapTile
    '        End If
    '    Next

    '    'Determine what direction we must move to go to this tile
    '    For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '        If CurrentMapTile.LinkedTiles(i).Equals(HighestMyAntPersistentPheromoneStrengthMapTile) Then
    '            MoveDirection = CType(i, Direction)
    '            Exit For
    '        End If
    '    Next
    '    Return MoveDirection
    'End Function

    Private Function ChooseHighestNonOccupiedAdjacentMyAntPersistentPheromoneStrengthDirection() As Direction Implements IColonyAntMovementController.GoTowardMyAntPersistentPheromone
        Dim MoveDirection As Direction
        'Determine highest food strength value for inputted food item ID of all adjacent tiles
        Dim HighestMyAntPersistentPheromoneStrengthMapTile As MapTile = CurrentMapTile.LinkedTiles(0) 'Set default value to prevent null ref
        Dim HighestMyAntPersistentPheromoneStrengthValue As Integer = Integer.MinValue
        For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
            If MapTile.MyAntPersistentPheromoneStrength >= HighestMyAntPersistentPheromoneStrengthValue AndAlso MapTile.AntHere = False Then
                HighestMyAntPersistentPheromoneStrengthValue = MapTile.MyAntPersistentPheromoneStrength
                HighestMyAntPersistentPheromoneStrengthMapTile = MapTile
            End If
        Next

        'Determine what direction we must move to go to this tile
        For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
            If CurrentMapTile.LinkedTiles(i).Equals(HighestMyAntPersistentPheromoneStrengthMapTile) Then
                MoveDirection = CType(i, Direction)
                Exit For
            End If
        Next
        Return MoveDirection
    End Function



#End Region

#Region "My Ant Persistent - Away"

    Public Function GoAwayFromMyAntPersistentPheromone As Direction Implements IColonyAntMovementController.GoAwayFromMyAntPersistentPheromone
        Dim MoveDirection As Direction
        Dim LowestMyAntPersistentPheromoneValue As Integer
        
        LowestMyAntPersistentPheromoneValue = GetLowestAdjacentNonOccupiedMyAntPersistentPheromoneStrengthValue
        MoveDirection = ChooseLowestAdjacentNonOccupiedMyAntPersistentPheromoneStrengthDirection(LowestMyAntPersistentPheromoneValue)
        
        Return MoveDirection
    End Function

    'Private Function ChooseLowestAdjacentMyAntPersistentPheromoneStrengthDirection(pLowestStrengthValue As Integer) As Direction
    '    Dim MoveDirection As Direction
    '    If pLowestStrengthValue = -1
    '        'There is no valid move... set move direction to north just because... prevents null ref 
    '        MoveDirection = Direction.n
    '    Else
    
    '        'Create list of all map tiles with the lowest MyAntHill Strength (may be multiple tiles)
    '        Dim LowestMapTiles As New List(Of MapTile)

    '        Try
    '            For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
    '                If MapTile.GetMyAntPersistentPheromoneStrength = pLowestStrengthValue Then
    '                    LowestMapTiles.Add(MapTile)
    '                End If
    '            Next

    '        Catch ex As Exception
    '            Throw New Exception("Error in 1 - " & ex.Message)
    '        End Try

    '        'Now we have a list of lowest adjacent map tiles. Choose one randomly.
    '        Dim ChosenAdjacentMapTile As MapTile
    '        Try

    '            If LowestMapTiles.Count > 0
    '                ChosenAdjacentMapTile = LowestMapTiles(_Random.Next Mod LowestMapTiles.Count)
    '            Else
    '                Throw New Exception("Lowest Map Tiles Count = 0!!!!, " & _ 
    '                                    "LowestStrengthValue=" & pLowestStrengthValue & ", " & _
    '                                    "CountLinkedTiles=" & CurrentMapTile.LinkedTiles.Length & ", " & _
    '                                    "0= " & CurrentMapTile.LinkedTiles(0).GetMyAntPersistentPheromoneStrength & ", " & _
    '                                    "1= " & CurrentMapTile.LinkedTiles(1).GetMyAntPersistentPheromoneStrength & ", " & _
    '                                    "2= " & CurrentMapTile.LinkedTiles(2).GetMyAntPersistentPheromoneStrength & ", " & _
    '                                    "3= " & CurrentMapTile.LinkedTiles(3).GetMyAntPersistentPheromoneStrength & ", ")
    '            End If
    '        Catch ex As Exception
    '            Throw New Exception("Error in ChooseLowestAdjacentMyAntPheromoneStrengthDirection - " & ex.Message)
    '        End Try

    '        Try

    '            'Determine what direction we must move to go to this tile
    '            For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
    '                If CurrentMapTile.LinkedTiles(i).Equals(ChosenAdjacentMapTile) Then
    '                    MoveDirection = CType(i, Direction)
    '                    Exit For
    '                End If
    '            Next
    '        Catch ex As Exception
    '            Throw New Exception("Error in 3 - " & ex.Message)
    '        End Try
    '    End If
    '    Return MoveDirection
    'End Function

    Private Function ChooseLowestAdjacentNonOccupiedMyAntPersistentPheromoneStrengthDirection(pLowestStrengthValue As Integer) As Direction
        Dim MoveDirection As Direction
        If pLowestStrengthValue = -1
            'There is no valid move... set move direction to north just because... prevents null ref 
            MoveDirection = Direction.n
        Else
    
            'Create list of all map tiles with the lowest MyAntHill Strength (may be multiple tiles)
            Dim LowestMapTiles As New List(Of MapTile)

            Try
                For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
                    If MapTile.GetMyAntPersistentPheromoneStrength = pLowestStrengthValue AndAlso MapTile.AntHere = False Then
                        LowestMapTiles.Add(MapTile)
                    End If
                Next

            Catch ex As Exception
                Throw New Exception("Error in 1 - " & ex.Message)
            End Try

            'Now we have a list of lowest adjacent map tiles. Choose one randomly.
            Dim ChosenAdjacentMapTile As MapTile
            Try

                If LowestMapTiles.Count > 0
                    ChosenAdjacentMapTile = LowestMapTiles(_Random.Next Mod LowestMapTiles.Count)
                Else
                    Throw New Exception("Lowest Map Tiles Count = 0!!!!, " & _ 
                                        "LowestStrengthValue=" & pLowestStrengthValue & ", " & _
                                        "CountLinkedTiles=" & CurrentMapTile.LinkedTiles.Length & ", " & _
                                        "0= " & CurrentMapTile.LinkedTiles(0).GetMyAntPersistentPheromoneStrength & ", " & _
                                        "1= " & CurrentMapTile.LinkedTiles(1).GetMyAntPersistentPheromoneStrength & ", " & _
                                        "2= " & CurrentMapTile.LinkedTiles(2).GetMyAntPersistentPheromoneStrength & ", " & _
                                        "3= " & CurrentMapTile.LinkedTiles(3).GetMyAntPersistentPheromoneStrength & ", ")
                End If
            Catch ex As Exception
                Throw New Exception("Error in ChooseLowestAdjacentMyAntPheromoneStrengthDirection - " & ex.Message)
            End Try

            Try

                'Determine what direction we must move to go to this tile
                For i As Integer = 0 To CurrentMapTile.LinkedTiles.Length - 1
                    If CurrentMapTile.LinkedTiles(i).Equals(ChosenAdjacentMapTile) Then
                        MoveDirection = CType(i, Direction)
                        Exit For
                    End If
                Next
            Catch ex As Exception
                Throw New Exception("Error in 3 - " & ex.Message)
            End Try
        End If
        Return MoveDirection
    End Function

    Private Function GetLowestAdjacentNonOccupiedMyAntPersistentPheromoneStrengthValue() As Integer
        'Find the lowest MyAntHill Strength of all adjacent tiles
        Dim LowestStrengthValue As Integer = Integer.MaxValue
        For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
            If MapTile.GetMyAntPersistentPheromoneStrength < LowestStrengthValue And MapTile.Passable And MapTile.AntHere = False Then
                LowestStrengthValue = MapTile.GetMyAntPersistentPheromoneStrength
            End If
        Next


        'If LowestStrengthValue = Integer.MaxValue
        '    LowestStrengthValue = -1
        '    Throw New Exception("LowestStrengthValue=" & LowestStrengthValue & ", " & _ 
        '                        "Linked(0)=" & CurrentMapTile.LinkedTiles(0).GetMyAntHillStrength & "-" & CurrentMapTile.LinkedTiles(0).Passable & ", " & _
        '                        "Linked(1)=" & CurrentMapTile.LinkedTiles(1).GetMyAntHillStrength & "-" & CurrentMapTile.LinkedTiles(1).Passable & ", " & _
        '                        "Linked(2)=" & CurrentMapTile.LinkedTiles(2).GetMyAntHillStrength & "-" & CurrentMapTile.LinkedTiles(2).Passable & ", " & _
        '                        "Linked(3)=" & CurrentMapTile.LinkedTiles(3).GetMyAntHillStrength & "-" & CurrentMapTile.LinkedTiles(3).Passable & ", ")
        'End If



        Return LowestStrengthValue
    End Function


#End Region

#Region "Random Walk"

    Private Function GetRandomWalkMoveDirection() As Direction
        Dim MoveDirection As Direction = Direction.w 'Set a default move direction....

        'Walk in a straight line until either the forward unit is not-passable, or we have walked in a straight line enough times
        '' to warrant turning in a random direction 90 degrees (180 degrees if we have to).

        If _StepCount < STEPCOUNTTHRESHOLD And CheckIfPassable(_PreviousDirection) And CurrentMapTile.LinkedTiles(_PreviousDirection).AntHere = False Then
            MoveDirection = _PreviousDirection   'Keep moving in a straight line, so move forward in previous direction
        Else 'Cannot keep going straight, need to turn left or right or turn around.

            'Perform a Mod 2 over a random number to get a 50-50 of a 0 or a 1 returned to represent a Boolean
            Dim ClockwiseTurn As Boolean = Convert.ToBoolean(_Random.Next Mod 2)
            MoveDirection = GetTurn90DegreeDirection(_PreviousDirection, ClockwiseTurn)

            'Verify new direction is passable, If not, try other direction
            If Not CheckIfPassable(MoveDirection) Or CurrentMapTile.LinkedTiles(MoveDirection).AntHere = True Then
                MoveDirection = GetTurn90DegreeDirection(_PreviousDirection, Not ClockwiseTurn)

                'Now, Verify is the New New direction is passable, if it isnt, then turn around from Previous direction
                If Not CheckIfPassable(MoveDirection)  Or CurrentMapTile.LinkedTiles(MoveDirection).AntHere = True Then
                    MoveDirection = GetTurn180DegreeDirection(_PreviousDirection)
                End If
            End If

        End If

        Return MoveDirection
    End Function

#End Region

#Region "Go Explore"
    Public Function GoExplore() As Direction Implements IColonyAntMovementController.GoExplore
        Dim MoveDirection As Direction
        Dim LowestMyAntPersistentPheromoneValue As Integer
        Dim LowestTiles As New List(Of MapTile)
        Dim SelectedTile As MapTile
        
        'Find the lowest My Ant Persistent Pheromone
        LowestMyAntPersistentPheromoneValue = GetLowestAdjacentNonOccupiedMyAntPersistentPheromoneStrengthValue

        If LowestMyAntPersistentPheromoneValue < Integer.MaxValue

            'Go through all the linked tiles and find all directions that have the lowest value
            For Each MapTile As MapTile In CurrentMapTile.LinkedTiles
                If MapTile.GetMyAntPersistentPheromoneStrength = LowestMyAntPersistentPheromoneValue And MapTile.Passable And MapTile.AntHere = False
                    LowestTiles.Add(MapTile)
                End If
            Next

            With LowestTiles
                If .Count = 4
                    'All tiles are the same, so commence a random walk
                    MoveDirection = GetRandomWalkMoveDirection
                ElseIf .Count > 0 AndAlso .Count < 4
                    'Randomly select a tile of the listed lowest tiles
                    Dim RandIndex As Integer = _Random.Next Mod .Count
                    SelectedTile = .Item(RandIndex)

                    'Random tile is chosen. Now find out what direction it is...
                    For i As Integer = 0 to CurrentMapTile.LinkedTiles.Length-1
                        If SelectedTile.Equals(CurrentMapTile.LinkedTiles(i))
                            MoveDirection = CType(i, Direction)
                            Exit For
                        End If
                    Next
                Else
                    Throw New Exception("Error in GoExplore - LowestTiles.Count is invalid: " & .Count)
                End If
            End With
        Else
            'If the lowest value is MAXVALUE, then that means there are no allowable moves. This most likely means all squares
            'immediately adjacent to the current location are either impassable or an ant exists there.
            'Therefore, lets just set the direction to north and exit. The ant wont actually move there anyway.
            MoveDirection = Direction.n
        End If

        Return MoveDirection
    End Function
#End Region

#Region "Go Combat"
    Public Function GoCombat() As Direction Implements IColonyAntMovementController.GoCombat
        Dim MoveDirection As Direction
        
        If CountEnemyAntsNearby <= CountMyAntsNearby Then
            MoveDirection = GoTowardsEnemyAntPheromone()
        Else
            'MoveDirection = ChooseHighestNonOccupiedAdjacentMyAntPersistentPheromoneStrengthDirection()
            If CountMyAntsNearby > 0
                MoveDirection = GoTowardsMyAntImmediatePheromone
            Else
                MoveDirection = ChooseHighestNonOccupiedAdjacentMyAntPersistentPheromoneStrengthDirection()
            End If
        End If

        Return MoveDirection
    End Function
#End Region

#Region "Go Defend Ant Hill"
    Public Function GoDefendAntHill() As Direction Implements IColonyAntMovementController.GoDefendAntHill
        Dim MoveDirection As Direction

        'For now our Defend Ant Hill logic will just tell ants to go towards the ant hill
        MoveDirection = ChooseHighestNonOccupiedAdjacentMyAntHillStrengthDirection()

        Return MoveDirection
    End Function
#End Region

#Region "Misc Movement Helper Logic"

    Public Function CheckIfPassable(pDirection As Direction) As Boolean
        Return CurrentMapTile.LinkedTiles(pDirection).Passable
    End Function

    Private Function GetTurn90DegreeDirection(pCurrentDirection As Direction, pClockwiseTurn As Boolean) As Direction
        Dim NewDirection As Direction = _PreviousDirection    'Set this to a value to prevent null ref 

        'I hate this algorithm... it is a stupid brute force. Need to fine a more elegant way to compute this.
        If pClockwiseTurn Then
            Select Case pCurrentDirection
                Case Direction.n
                    NewDirection = Direction.e
                Case Direction.e
                    NewDirection = Direction.s
                Case Direction.s
                    NewDirection = Direction.w
                Case Direction.w
                    NewDirection = Direction.n
            End Select
        Else
            Select Case pCurrentDirection
                Case Direction.n
                    NewDirection = Direction.w
                Case Direction.e
                    NewDirection = Direction.n
                Case Direction.s
                    NewDirection = Direction.e
                Case Direction.w
                    NewDirection = Direction.s
            End Select
        End If

        Return NewDirection
    End Function

    Private Function GetTurn180DegreeDirection(pCurrentDirection As Direction) As Direction
        Dim NewDirection As Direction = _PreviousDirection 'Set this to a value to prevent null ref

        Select Case pCurrentDirection
            Case Direction.n
                NewDirection = Direction.s
            Case Direction.e
                NewDirection = Direction.w
            Case Direction.s
                NewDirection = Direction.n
            Case Direction.w
                NewDirection = Direction.e
        End Select

        Return NewDirection
    End Function

#End Region


End Class
