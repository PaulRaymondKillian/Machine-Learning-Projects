﻿Option Strict On

Imports System.Collections.Generic
Imports System.Collections.Hashtable
Imports System.Collections

Public Structure CombatAntsPerEnemyAntContainer
    Public EnemyAnt As String
    Public MyCombatAnts As List(Of ColonyAnt)
End Structure

Public Class CombatInfoContainer
    Public CombatAntsPerEnemyAnt As List(Of CombatAntsPerEnemyAntContainer)

    Public Sub New
        CombatAntsPerEnemyAnt = New List(Of CombatAntsPerEnemyAntContainer)
    End Sub

    Public Sub PopulateCombatAntsPerEnemyAntList(pCombatAnts As List(Of ColonyAnt))
        Dim CurrentContainer As CombatAntsPerEnemyAntContainer
        For Each MyAnt As ColonyAnt In pCombatAnts
            For Each MapTile As MapTile In MyAnt.CurrentMapTile.LinkedTiles
                For Each EnemyAnt As String In MapTile.EnemyAntPheromoneStrengthHash.Keys
                    CurrentContainer = GetContainerForEnemyAnt(EnemyAnt)
                    If Not CurrentContainer.MyCombatAnts.Contains(MyAnt)
                        CurrentContainer.MyCombatAnts.Add(MyAnt)
                    End If
                Next
            Next
        Next
    End Sub

    Public Function GetContainerForEnemyAnt(pEnemyAnt As String) As CombatAntsPerEnemyAntContainer
        Dim SelectedContainer As New CombatAntsPerEnemyAntContainer
        Dim FoundContainer As Boolean = False
        For Each Container As CombatAntsPerEnemyAntContainer In CombatAntsPerEnemyAnt
            If Container.EnemyAnt = pEnemyAnt
                SelectedContainer = Container
                FoundContainer = True
                Exit For
            End If
        Next
        If Not FoundContainer
            SelectedContainer.EnemyAnt = pEnemyAnt
            SelectedContainer.MyCombatAnts = New List(Of ColonyAnt)
            CombatAntsPerEnemyAnt.Add(SelectedContainer)
        End If
        Return SelectedContainer
    End Function

End Class
