﻿Option Strict On

Imports System.Collections.Generic
Imports System.Collections.Hashtable
Imports System.Collections

Public Interface IColonyAntsCombatEngine
    Sub ExecuteColonyAntsCombatEngine(pTurnCount As Integer, pColonyAnts As List(Of ColonyAnt), pColonyAntHills As List(Of ColonyAntHill), _
                                                pEnemyAntLocations As List(Of Location), pEnemyAntHillLocations As List(Of Location), _ 
                                                pArchivedEnemyAntHills As List(Of Location), pDestroyedEnemyAntHills As List(Of Location), _ 
                                                pMap As MapData)
End Interface

Public Structure CombatAntsPerEnemyAntContainer
    Public EnemyAntLocation As Location
    Public MyCombatAnts As List(Of ColonyAnt)
End Structure

Public Class ColonyAntsCombatEngine : Implements IColonyAntsCombatEngine
    Public Sub New

    End Sub

    Public Sub ExecuteColonyAntsCombatEngine(pTurnCount As Integer, pColonyAnts As List(Of ColonyAnt), pColonyAntHills As List(Of ColonyAntHill), _
                                                pEnemyAntLocations As List(Of Location), pEnemyAntHillLocations As List(Of Location), _ 
                                                pArchivedEnemyAntHills As List(Of Location), pDestroyedEnemyAntHills As List(Of Location), _ 
                                                pMap As MapData) Implements IColonyAntsCombatEngine.ExecuteColonyAntsCombatEngine

        Dim MyCombatAnts As New List(Of ColonyAnt)
        Dim MyHillDefenseAnts As New List(Of ColonyAnt)
        Dim CombatAntsPerEnemyAntList As New List(Of CombatAntsPerEnemyAntContainer)
        Dim EnemyAntCombatAntListHash As New Hashtable

        'Gather a list of all of my ants that are near enemy ants. We can then ignore all other ants because they don't immediately matter
        For Each MyAnt As ColonyAnt In pColonyAnts
            For Each AdjTile As MapTile In MyAnt.CurrentMapTile.LinkedTiles
                If AdjTile.EnemyAntPheromoneStrengthHash.Count > 0
                    MyCombatAnts.Add(MyAnt)

                    'Find out of this ant is near my ant hill, if so, add them to the defense ant list as well
                    If MyAnt.CurrentMapTile.MyAntHillStrength > 0 Then
                        MyHillDefenseAnts.Add(MyAnt)
                    End If

                    Exit For 'We added the ant, exit the for loop and look at the other my ants
                End If
            Next
        Next
        
        ''Create a list of my ants near each enemy ant, use "index" of pEnemyAntLocations as the key for the hash table
        'For Index As Integer = 0 to pEnemyAntLocations.Count-1
        '    For Each MyAnt As ColonyAnt In MyCombatAnts
        '        For Each AdjTile As MapTile In MyAnt.CurrentMapTile.LinkedTiles
        '            If CInt(AdjTile.EnemyAntPheromoneStrengthHash.Item(pMap.GetMapTile(pEnemyAntLocations(Index).Row, pEnemyAntLocations(Index).Col).ID)) > 0
        '                'If CombatAntsPerEnemyAntList.
        '                If Not EnemyAntCombatAntListHash.ContainsKey(Index)
        '                    EnemyAntCombatAntListHash.Add(Index, New List(Of ColonyAnt))
        '                End If
        '                CType(EnemyAntCombatAntListHash.Item(Index), List(Of ColonyAnt)).Add(MyAnt)
        '                Exit For'We added this ant for this enemy ant in the hash table, go on to the next ant
        '            End If
        '        Next
        '    Next
        'Next

        ''Transpose the kinda convoluted hashtable to the list of the combat ants structure
        'For Each Key As String In EnemyAntCombatAntListHash.Keys
        '    Dim NewStructure As CombatAntsPerEnemyAntContainer
        '    NewStructure.EnemyAntLocation = pEnemyAntLocations(CInt(Key))
        '    NewStructure.MyCombatAnts = CType(EnemyAntCombatAntListHash.Item(CInt(Key)), List(Of ColonyAnt))
        '    CombatAntsPerEnemyAntList.Add(NewStructure)
        'Next

        ''Now we have a nice list of objects that contain information on enemy ants and nearby my ants... lets do stuff with it now.

        ''Find the enemy ant who has the most of my ants nearby
        'Dim HighestCombatContainer As CombatAntsPerEnemyAntContainer
        'Dim HighestMyAntCount As Integer = Integer.MinValue
        'For Each Container As CombatAntsPerEnemyAntContainer In CombatAntsPerEnemyAntList
        '    If Container.MyCombatAnts.Count > HighestMyAntCount
        '        HighestMyAntCount = Container.MyCombatAnts.Count
        '        HighestCombatContainer = Container
        '    End If
        'Next

        'If Not HighestCombatContainer.MyCombatAnts Is Nothing
        '    IssueCombatOrdersForEnemyAnt(HighestCombatContainer.EnemyAntLocation, HighestCombatContainer.MyCombatAnts)
        'End If


    End Sub

    Public Sub IssueCombatOrdersForEnemyAnt(pEnemyAntLocation As Location, pMyCombatAnts As List(Of ColonyAnt))

    End Sub
End Class
