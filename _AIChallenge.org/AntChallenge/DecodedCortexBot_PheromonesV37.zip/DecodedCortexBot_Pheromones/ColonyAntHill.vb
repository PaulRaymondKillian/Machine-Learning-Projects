﻿Option Strict On

Imports System.Collections.Generic

Public Class ColonyAntHill
    Public _AntHill As MapTile
    Public _LookoutTower As List(Of MapTile)
    Public _MAXALERTSTRENGTH As Integer

    Public Sub New(pAntHillMapTile As MapTile, Optional pMAXALERTSTRENGTH As Integer = 8)
        _AntHill = pAntHillMapTile
        _MAXALERTSTRENGTH = pMAXALERTSTRENGTH
        _LookoutTower = New List(Of MapTile)
    End Sub

    Public Sub CalculateLookoutTowerLocations(pRadius As Integer)
        Dim N As MapTile = _AntHill
        Dim S As MapTile = _AntHill
        Dim E As MapTile = _AntHill
        Dim W As MapTile = _AntHill

        
        For i As Integer = 0 to pRadius
            N = N.LinkedTiles(Direction.n)
            S = S.LinkedTiles(Direction.s)
            E = E.LinkedTiles(Direction.e)
            W = W.LinkedTiles(Direction.w)
        Next

        If N.Passable
            _LookoutTower.Add(N)
        End If
        If S.Passable
            _LookoutTower.Add(S)
        End If
        If E.Passable
            _LookoutTower.Add(E)
        End If
        If W.Passable
            _LookoutTower.Add(W)
        End If

        'If NONE of the possible lookout positions are valid positions, then just set the Ant Hill as a lookout station.
        ''It is better than nothing and prevents null references
        If _LookoutTower.Count = 0
            _LookoutTower.Add(_AntHill)
        End If

    End Sub

    Public Sub CheckLookoutTowers()
        For Each Tower As MapTile In _LookoutTower  
            If Tower.GetEnemyAntPheromoneStrength > 0
                Tower.SetAlertTileStrength(_MAXALERTSTRENGTH)
            End If
        Next
    End Sub


End Class
