﻿Option Strict On

Imports System.Collections.Generic
Imports System.Collections.Hashtable
Imports System.Collections

Public Interface IColony
    Sub UpdateColony(pMapTiles(,) As Tile, pFoodLocations As List(Of Location), pAntLocations As List(Of Location), _
                            pMyAntHillLocation As List(Of Location), pEnemyAntHillLocation As List(Of Location), _
                            pEnemyAntLocations As List(Of Location), pAntViewRadius As Integer)
    Function GetMapTile(pRow As Integer, pCol As Integer) As MapTile
    Function GetAntMoveDirection(pAntLocation As Location) As Direction
    Sub MoveAnt(pAntLocation As Location, pMoveDirection As Direction)
    Function AntExistAtLocation(pLocation As Location) As Boolean

    Function xGetAnts() As List(Of ColonyAnt)   'Debugging Logic Method
End Interface

'Public Structure EnemyAntHill
'    Public Location As Location
'    Public Destroyed As Boolean
'    Public Sub New(pLocation As Location, Optional pDestroyed As Boolean = False)
'        Location = pLocation
'        Destroyed = pDestroyed
'    End Sub
'End Structure

Public Class Colony : Implements IColony
    Private _ColonyAnts As List(Of ColonyAnt)
    Private _ColonyAntHills As List(Of ColonyAntHill)
    Public _Map As MapData
    Private _EnemyAntHillMemoryTTL As Hashtable
    Const MAXENEMYANTHILLMEMORYTTL As Integer = 25
    Private _ArchivedEnemyAntHills As List(Of Location)
    Private _DestroyedEnemyAntHills As List(Of Location)
    Private _Random As New Random(Now.Millisecond)
    Private _TurnCount As Integer
    Private _TurnsSinceLastSeenEnemyAntHill As Integer

    Const _PREDICTIONMINTURNCOUNT As Integer = 50
    Const _PREDICTIONSINCELASTSEENHILL As Integer = 30
    Const _PREDICTIONMINMYANTCOUNT As Integer = 15
    Const _MAXCOUNTPREDICTEDENEMYANTHILLSALLOWED As Integer = 15    'How many ant hills should be generated before we consider an error occurred

    Public Sub New(pMapRows As Integer, pMapCols As Integer)
        _Map = New MapData(pMapRows, pMapCols)
        _ColonyAnts = New List(Of ColonyAnt)
        _ColonyAntHills = New List(Of ColonyAntHill)
        _EnemyAntHillMemoryTTL = New Hashtable
        _ArchivedEnemyAntHills = New List(Of Location)
        _DestroyedEnemyAntHills = New List(Of Location)
        _TurnCount = 0
        _TurnsSinceLastSeenEnemyAntHill = 0
    End Sub

    Public Sub UpdateColony(pMapTiles(,) As Tile, pFoodLocations As List(Of Location), pAntLocations As List(Of Location), _
                                                pMyAntHillLocation As List(Of Location), pEnemyAntHillLocations As List(Of Location), _
                                                pEnemyAntLocations As List(Of Location), pAntViewRadius As Integer) Implements IColony.UpdateColony
        
        _TurnCount += 1
        UpdateColonyAnts(pAntLocations)
        UpdateColonyAntHills(pMyAntHillLocation)
        MaintainEnemyAntHillArchive(pEnemyAntHillLocations)

        'Perform Enemy Ant Hill Maintainance Logic / Archival / Prediction
        If pEnemyAntHillLocations.Count = 0
            _TurnsSinceLastSeenEnemyAntHill += 1
            If CheckPredictEnemyAntHillLocationNow()
                pEnemyAntHillLocations = PredictEnemyAntHillLocation()
                _TurnsSinceLastSeenEnemyAntHill = 0
            End If
        Else
            _TurnsSinceLastSeenEnemyAntHill = 0
        End If

        Dim ActiveEnemyAntHillLocations As List(Of Location) = GetActiveEnemyAntHillLocations(pEnemyAntHillLocations)
        MaintainDestroyedEnemyAntHillList(ActiveEnemyAntHillLocations, pAntLocations)
        UpdateMapData(pMapTiles, pFoodLocations, pMyAntHillLocation, ActiveEnemyAntHillLocations, pAntLocations, pEnemyAntLocations, pAntViewRadius)
        
        For Each AntHill As ColonyAntHill In _ColonyAntHills
            AntHill.CalculateLookoutTowerLocations(5)
            AntHill.CheckLookoutTowers
        Next

    End Sub

    Public Sub MaintainDestroyedEnemyAntHillList(pEnemyAntHills As List(Of Location), pMyAnts As List(Of Location))
        For Each EnemyAntHill As Location In pEnemyAntHills
            For Each MyAnt As Location In pMyAnts
                If EnemyAntHill.Row = MyAnt.Row AndAlso EnemyAntHill.Col = MyAnt.Col
                    'My ant currently exists on the location of an enemy ant hill (predicted or real hill)
                    'Check if the Enemy Ant hill location currently exists in the list of destroyed hills
                    If Not _DestroyedEnemyAntHills.Contains(EnemyAntHill)
                        _DestroyedEnemyAntHills.Add(EnemyAntHill)   'Add the hill to the list of "destroyed" hills
                    End If
                End If
            Next
        Next
    End Sub

    Public Sub MaintainEnemyAntHillArchive(pEnemyAntHillLocations as List(Of Location))
        If pEnemyAntHillLocations.Count > 0
            For Each AntHillLocation As Location In pEnemyAntHillLocations
                If Not _ArchivedEnemyAntHills.Contains(AntHillLocation)
                    _ArchivedEnemyAntHills.Add(AntHillLocation)
                End If
            Next
        End If
    End Sub

    Public Function CheckPredictEnemyAntHillLocationNow() As Boolean
        If _TurnCount > _PREDICTIONMINTURNCOUNT AndAlso _TurnsSinceLastSeenEnemyAntHill > _PREDICTIONSINCELASTSEENHILL AndAlso _ColonyAnts.Count > _PREDICTIONMINMYANTCOUNT
            Return True
        Else
            Return False
        End If
    End Function

    Public Function PredictEnemyAntHillLocation() As List(Of Location)
        Dim PredictedEnemyAntHillLocation As New List(Of Location)

        'We must have at least 1 colony ant hill for this logic to work, we base our calcs off _ColonyAntHill(0) member of list
        If _ColonyAntHills.Count > 0
            If _ArchivedEnemyAntHills.Count = 0
                PredictedEnemyAntHillLocation = GeneratePossibleEnemyAntHillLocations()
                'PredictedEnemyAntHillLocation.Add(GetNearbyValidMapLocation(EnemyAntHill1))
            Else
                PredictedEnemyAntHillLocation = GenerateExpectedEnemyAntHillLocations()
            End If
        End If

        'For Each Location As Location In PredictedEnemyAntHillLocation
        '    MsgBox(_TurnCount & " - (" & Location.Row & "," & Location.Col & ")")
        'Next

        Return PredictedEnemyAntHillLocation
    End Function

    Public Function GenerateExpectedEnemyAntHillLocations() As List(Of Location)
        'If we have seen an enemy ant hill, use this logic to calculate where we should expect an ant hill to be.
        Dim PredictedEnemyAntHillLocation As New List(Of Location)
        Dim MyAntHill As Location = New Location(_ColonyAntHills(0)._AntHill.Row, _ColonyAntHills(0)._AntHill.Col)
        Dim RandomArchivedEnemyAntHill As Location = _ArchivedEnemyAntHills(_Random.Next Mod _ArchivedEnemyAntHills.Count)
        Dim DeltaRows As Integer = MyAntHill.Row - RandomArchivedEnemyAntHill.Row
        Dim DeltaCols As Integer = MyAntHill.Col - RandomArchivedEnemyAntHill.Col
        Dim CurrentPredictedEnemyAntHill As Location = MyAntHill
        Dim DonePredicting As Boolean = False
        Dim PredictionInvalid As Boolean = False

        Do
            CurrentPredictedEnemyAntHill.Row = GetValidRowIndex(CurrentPredictedEnemyAntHill.Row + DeltaRows)
            CurrentPredictedEnemyAntHill.Col = GetValidColIndex(CurrentPredictedEnemyAntHill.Col + DeltaCols)

            'If Not (CurrentPredictedEnemyAntHill.Row = MyAntHill.Row AndAlso CurrentPredictedEnemyAntHill.Col = MyAntHill.Col)
            If GetDistance(MyAntHill, CurrentPredictedEnemyAntHill) > 2
                PredictedEnemyAntHillLocation.Add(CurrentPredictedEnemyAntHill)
            ElseIf PredictedEnemyAntHillLocation.Count >= _MAXCOUNTPREDICTEDENEMYANTHILLSALLOWED Or DeltaCols = 0 or DeltaRows = 0
                PredictionInvalid = True
            Else
                DonePredicting = True    
            End If
        Loop Until DonePredicting Or PredictionInvalid

        If Not PredictionInvalid
            'We should have a list of all predicted enemy ant hills now. 
            'Our next step is to remove all predicted enemy ant hills that are already known to be destroyed
            PredictedEnemyAntHillLocation = RemoveLocationsFromListOfLocations(PredictedEnemyAntHillLocation, _DestroyedEnemyAntHills)

            'We now have a list of predicted ant hills that have not been seen before. Choose the closest one to my ant hill and 
            'return it as our predicted enemy ant hill.
            Dim ValidPredictedEnemyAntHillLocation As New List(Of Location)
            For Each ColonyAntHill As ColonyAntHill In _ColonyAntHills
                MyAntHill = New Location(ColonyAntHill._AntHill.Row, ColonyAntHill._AntHill.Col)
                'Calculate the closest valid (non-destroyed) ant hill to each of my ant hills
                Dim ClosestValidPredictedLocation As Location = ReturnClosestValidEnemyAntHillLocation(MyAntHill, PredictedEnemyAntHillLocation)
                
                'Check if the calculated ant hill already exists in the predicted list, if not, add it
                If Not ValidPredictedEnemyAntHillLocation.Contains(ClosestValidPredictedLocation)
                    ValidPredictedEnemyAntHillLocation.Add(ClosestValidPredictedLocation)
                End If
            Next
            PredictedEnemyAntHillLocation = ValidPredictedEnemyAntHillLocation
        Else
            'Our calculate of expected enemy ant hills produced too many results and therefore we do not expect them to be correct or
            'accurate. Throw away these calculations and instead guess where the enemy ant hills may be...
            PredictedEnemyAntHillLocation = GeneratePossibleEnemyAntHillLocations
        End If

        Return PredictedEnemyAntHillLocation
    End Function

    Public Function GeneratePossibleEnemyAntHillLocations() As List(Of Location)
        Dim PredictedEnemyAntHillLocation As New List(Of Location)
        Dim PercentMapToCover As Double
        Dim PredictSingleLocation As Boolean = False
        Dim FoundValidPredictions As Boolean
        'If we have never seen an enemy ant hill yet, use this logic to predic where an enemy ant hill may be
            
        'Heuristically expect an ant hill to be a distance of perhaps XX% of the map away in both directions
        If _ColonyAnts.Count < 50
            PercentMapToCover = 0.25
        ElseIf _ColonyAnts.Count < 150
            PercentMapToCover = 0.4
        Else
            'We we have over 150 ants, just create a single location at the exact opposite side of the map from my ant hill location...
            PercentMapToCover = 0.5
            PredictSingleLocation = True
        End If
        Dim DeltaRows As Integer = CInt(_Map._Rows*PercentMapToCover)
        Dim DeltaCols As Integer = CInt(_Map._Cols*PercentMapToCover)

        'Calculate the 4 closest ant hills using the heuristically calculated delta distance values
        'Dim EnemyAntHill1 As New Location
        'EnemyAntHill1.Row = (_ColonyAntHills(0)._AntHill.Row + DeltaRows) Mod _Map._Rows
        'EnemyAntHill1.Col = (_ColonyAntHills(0)._AntHill.Col + DeltaCols) Mod _Map._Cols
        Do
            FoundValidPredictions = True    'Reset value to true, we will check if false at the end
            PredictedEnemyAntHillLocation.Clear 'Reset the list of predicted ant hills

            For Each MyColonyAntHill As ColonyAntHill In _ColonyAntHills
                With MyColonyAntHill._AntHill
                    If PredictSingleLocation
                        'Only generate a single enemy ant hill location on the exact opposite point of the map...
                        PredictedEnemyAntHillLocation.Add(GetNearbyValidMapLocation( _
                                                            New Location(GetValidRowIndex(.Row + DeltaRows), _
                                                                        GetValidColIndex(.Col + DeltaCols))))
                    Else
                        'Only generate two predicted enemy ant hill locations, in opposite directions of each other.
                        If( _Random.Next Mod 2 = 0)
                            PredictedEnemyAntHillLocation.Add(GetNearbyValidMapLocation( _
                                                            New Location(GetValidRowIndex(.Row + DeltaRows), _
                                                                        GetValidColIndex(.Col + DeltaCols))))
                
                            PredictedEnemyAntHillLocation.Add(GetNearbyValidMapLocation( _ 
                                                            New Location(GetValidRowIndex(.Row - DeltaRows), _
                                                                        GetValidColIndex(.Col - DeltaCols))))
                        Else
                            PredictedEnemyAntHillLocation.Add(GetNearbyValidMapLocation( _
                                                            New Location(GetValidRowIndex(.Row - DeltaRows), _
                                                                        GetValidColIndex(.Col + DeltaCols))))
                
                            PredictedEnemyAntHillLocation.Add(GetNearbyValidMapLocation( _
                                                            New Location(GetValidRowIndex(.Row + DeltaRows), _
                                                                        GetValidColIndex(.Col - DeltaCols))))
                        End If
                    End If
                End With
            Next

            'Now we calculated our predicted possible enemy ant hill locations. Lets make sure they are valid. If not, re-guess new locs
            For Each PredictedLocation As Location In PredictedEnemyAntHillLocation
                If _DestroyedEnemyAntHills.Contains(PredictedLocation)
                    'MsgBox("Invalid enemy ant hill predicted")
                    FoundValidPredictions = False
                    DeltaCols = CInt(DeltaCols * 1.1)   'Push the guessed enemy ant hill out further by 10%
                    DeltaRows = CInt(DeltaRows * 1.1)   'Push the guessed enemy ant hill out further by 10%
                End If
            Next
        Loop Until FoundValidPredictions

        Return PredictedEnemyAntHillLocation
    End Function

    Public Function GetValidColShortestDistance(pCol1 As Integer, pCol2 As Integer) As Integer
        Dim ShortestDistance As Integer
        Dim Dist1, Dist2 As Integer
        'This function is necessary because you cannot just do a simple subtraction to find the distance between two points.
        'Because the map is a continuum torus, we must look off the edges of the map to determine which direction is shortest.
        Dist1 = Math.Abs(pCol1 - pCol2)
        Dist2 = Math.Abs(Dist1 - _Map._Cols)

        If Dist1 < Dist2 Then
            ShortestDistance = Dist1
        Else
            ShortestDistance = Dist2
        End If

        Return ShortestDistance
    End Function

    Public Function GetValidRowShortestDistance(pRow1 As Integer, pRow2 As Integer) As Integer
        Dim ShortestDistance As Integer
        Dim Dist1, Dist2 As Integer
        'This function is necessary because you cannot just do a simple subtraction to find the distance between two points.
        'Because the map is a continuum torus, we must look off the edges of the map to determine which direction is shortest.
        Dist1 = Math.Abs(pRow1 - pRow2)
        Dist2 = Math.Abs(Dist1 - _Map._Rows)

        If Dist1 < Dist2 Then
            ShortestDistance = Dist1
        Else
            ShortestDistance = Dist2
        End If

        Return ShortestDistance
    End Function

    Public Function ReturnClosestValidEnemyAntHillLocation(pSourceLocation As Location, pListOfEnemyAntHills As List(Of Location)) As Location
        Dim ClosestValidLocation As Location
        Dim CurrentDistance As Integer
        Dim LowestDistance As Integer = Integer.MaxValue

        For Each Location As Location In pListOfEnemyAntHills
            If Not _DestroyedEnemyAntHills.Contains(Location)
                CurrentDistance = GetDistance(pSourceLocation, Location)
                If CurrentDistance < LowestDistance
                    LowestDistance = CurrentDistance
                    ClosestValidLocation = Location
                End If
            End If
        Next

        Return ClosestValidLocation
    End Function

    Public Function ReturnClosestLocation(pSourceLocation As Location, pListOfLocs As List(Of Location)) As Location
        Dim ClosestLocation As Location
        Dim CurrentDistance As Integer
        Dim LowestDistance As Integer = Integer.MaxValue

        For Each Location As Location In pListOfLocs
            CurrentDistance = GetDistance(pSourceLocation, Location)
            If CurrentDistance < LowestDistance
                LowestDistance = CurrentDistance
                ClosestLocation = Location
            End If
        Next

        Return ClosestLocation
    End Function

    Public Function GetDistance(pLocation1 As Location, pLocation2 As Location) As Integer
        Return CInt(Math.Sqrt(Math.Pow(GetValidRowShortestDistance(pLocation1.Row, pLocation2.Row), 2) + _ 
                              Math.Pow(GetValidColShortestDistance(pLocation1.Col, pLocation2.Col), 2)))
    End Function

    Public Function RemoveLocationsFromListOfLocations(pSourceLocations As List(Of Location), pLocsToRemove As List(Of Location)) As List(Of Location)
        For Each LocToRemove As Location In pLocsToRemove
            If pSourceLocations.Contains(LocToRemove)
                pSourceLocations.Remove(LocToRemove)
            End If
        Next
        Return pSourceLocations
    End Function

    Public Function GetValidRowIndex(pRowIndex As Integer) As Integer
        Dim RowIndex As Integer = pRowIndex

        Do Until RowIndex >= 0 AndAlso RowIndex < _Map._Rows
            If RowIndex < 0
                RowIndex = _Map._Rows + RowIndex    'Row index is negative, so it will essentially subtract from _Map._Rows
            End If
            RowIndex = RowIndex Mod _Map._Rows
        Loop

        Return RowIndex
    End Function

    Public Function GetValidColIndex(pColIndex As Integer) As Integer
        Dim ColIndex As Integer = pColIndex

        Do Until ColIndex >= 0 AndAlso ColIndex < _Map._Cols
            If ColIndex < 0
                ColIndex = _Map._Cols + ColIndex    'Col index is negative, so it will essentially subtract from _Map._Rows
            End If
            ColIndex = ColIndex Mod _Map._Cols
        Loop

        Return ColIndex
    End Function
                                                
    Public Function GetNearbyValidMapLocation(pLocation As Location) As Location
        Dim MapTile As MapTile = GetMapTile(pLocation.Row, pLocation.Col)
        Dim Turn As Boolean = False
        Dim PossibleErrorCounter As Integer = 0 'This is to prevent an infite loop if that were to somehow be possible on a specific map
        Do Until MapTile.Passable Or PossibleErrorCounter > 100
            If Turn
                MapTile = MapTile.LinkedTiles(CInt(Direction.w))
            Else
                MapTile = MapTile.LinkedTiles(CInt(Direction.n))
            End If
            PossibleErrorCounter += 1
        Loop
        Return New Location(MapTile.Row, MapTile.Col)
    End Function
        

    Private Sub UpdateMapData(pMapTiles(,) As Tile, pFoodLocations As List(Of Location), pMyAntHillLocations As List(Of Location), _
                                    pEnemyAntHillLocation As List(Of Location), pAntLocations As List(Of Location), _ 
                                    pEnemyAntLocations As List(Of Location), pAntViewRadius As Integer)

        _Map.UpdateMapPathfinderVariables(pMapTiles.Length, pFoodLocations.Count, pEnemyAntHillLocation.Count, pAntViewRadius, pAntLocations.Count, pEnemyAntLocations.Count)
        
        'If pMyAntHillLocations.Count > 0  Then
        '    _Map.UpdateMyAntHillLocations(pMyAntHillLocations) 'This must be done before UpdateMap
        'End If
        
        _Map.UpdateMapFoodItems(pFoodLocations)         'This must be done before UpdateMap
        _Map.UpdateMap(pMapTiles, pMyAntHillLocations.Count, pAntLocations.Count, pEnemyAntLocations.Count, pEnemyAntHillLocation.Count)                       'This must be done second (requires up to date list of FoodItems)
        
        'Dim ActiveEnemyAntHillLocations As List(Of Location) = GetActiveEnemyAntHillLocations(pEnemyAntHillLocation)
        'If ActiveEnemyAntHillLocations.Count > 0 Then
        '    _Map.UpdateMapEnemyAntHillLocation(ActiveEnemyAntHillLocations)
        'End If
        _Map.UpdateMapEnemyAntHillLocation(pEnemyAntHillLocation)

        _Map.UpdateMyAntHillsMap(pMyAntHillLocations)

        _Map.UpdateMyAntPheromoneMap(pAntLocations) 'This needs to be done after the UpdateMap function so we have an up-to-date map and ensure Pheromones decreased

        _Map.UpdateEnemyAntPheromoneMap(pEnemyAntLocations) 'This needs to be done after the UpdateMap function so we have an up-to-date map

    End Sub

    Public Function GetMapTile(pRow As Integer, pCol As Integer) As MapTile Implements IColony.GetMapTile
        Return _Map._Map(pRow, pCol)
    End Function


#Region "Maintain Colony Ant List Logic"

    Private Sub UpdateColonyAnts(pAntLocations As List(Of Location))
        'Add new ants to the list from the current list of colony ants
        For Each AntLocation As Location In pAntLocations
            If Not AntExists(AntLocation)
                AddNewAnt(AntLocation)
            End If
        Next

        'Remove ants from the colony ant list that are not in the newest ant list (therefore they no longer exist on the map)
        Dim AntsToBeRemoved As New List(Of ColonyAnt)
        For Each Ant As ColonyAnt In _ColonyAnts
            If Not AntLocationExistsInColonyAnts(Ant, pAntLocations)
                AntsToBeRemoved.Add(Ant)
            End If
        Next

        'Now actually remove the food items
        For Each Ant As ColonyAnt In AntsToBeRemoved
            RemoveAnt(Ant)
        Next
    End Sub

        Public Function AntExists(pAntLocation As Location) As Boolean
        Dim Exists As Boolean = False
        For Each ExistingAnt As ColonyAnt In _ColonyAnts
            If pAntLocation.Col = ExistingAnt.CurrentMapTile.Col AndAlso pAntLocation.Row = ExistingAnt.CurrentMapTile.Row
                Exists = True
                Exit For
            End If
        Next
        Return Exists
    End Function

    Public Function AntLocationExistsInColonyAnts(pColonyAnt As ColonyAnt, pAntList As List(Of Location)) As Boolean
        Dim Exists As Boolean = False
        For Each Ant As Location In pAntList
            If Ant.Col = pColonyAnt.CurrentMapTile.Col AndAlso Ant.Row = pColonyAnt.CurrentMapTile.Row
                Exists = True
                Exit For
            End If
        Next
        Return Exists
    End Function

    'Remove ColonyAnt from persistent list of ColonyAnts
    Public Sub RemoveAnt(pColonyAnt As ColonyAnt)
        For Each Ant As ColonyAnt In _ColonyAnts
            If Ant.Equals(pColonyAnt)
                _ColonyAnts.Remove(Ant)
                Exit For 'We found it and removed it, so stop looking!
            End If
        Next
    End Sub

#End Region
                                 

#Region "Colony Ant List Maintanence Logic"

    Public Function AddNewAnt(pLocation As Location) As ColonyAnt
        Dim newColonyAnt As ColonyAnt = New ColonyAnt(GetMapTile(pLocation.Row, pLocation.Col), _Random)
        _ColonyAnts.Add(newColonyAnt)
        Return newColonyAnt
    End Function

    Public Function GetAnt(pLocation As Location) As ColonyAnt
        Dim selectedAnt As New ColonyAnt(GetMapTile(pLocation.Row, pLocation.Col), _Random)
        Dim FoundAnt As Boolean = False
        If Not _ColonyAnts Is Nothing
            For Each ant As ColonyAnt In _ColonyAnts
                If pLocation.Col = ant.CurrentMapTile.Col AndAlso pLocation.Row = ant.CurrentMapTile.Row
                    selectedAnt = ant
                    FoundAnt = True
                End If
            Next
        End If
        'Ant must not have been in the list, add new ant.
        If FoundAnt = False
            selectedAnt = AddNewAnt(pLocation)    
        End If
        Return selectedAnt
    End Function

    'Public Sub UpdateAnt(pOldLoc As Location, pNewLoc As Location, pDirection As Direction)
    '    For Each ant As ColonyAnt In _ColonyAnts
    '        If pOldLoc.Col = ant.CurrentMapTile.Col AndAlso pOldLoc.Row = ant.CurrentMapTile.Row
    '            ant.CurrentMapTile = GetMapTile(pNewLoc.Row, pNewLoc.Col)
    '            ant.SetPreviousDirection(pDirection)
    '        End If
    '    Next
    'End Sub

#End Region


#Region "Ant Orders Logic"

    'Steps taken to move an ant.
    '1) Get desired move direction for each ant
    '2) Verify in the game that the move is valid (passable)
    '3) Actually move the ant in the colony object

    Public Function GetAntMoveDirection(pAntLocation As Location) As Direction Implements IColony.GetAntMoveDirection
        Dim MoveDirection As Direction

        MoveDirection = GetAnt(pAntLocation).GetAntMoveDirection

        Return MoveDirection
    End Function

    Public Sub MoveAnt(pAntLocation As Location, pMoveDirection As Direction) Implements IColony.MoveAnt
        GetAnt(pAntLocation).MoveAnt(pMoveDirection)
    End Sub

    #End Region

    Public Function AntExistAtLocation(pLocation As Location) As Boolean Implements IColony.AntExistAtLocation
        Dim AntExists As Boolean = False

        For Each Ant As ColonyAnt In _ColonyAnts
            If Ant.CurrentMapTile.Row = pLocation.Row AndAlso Ant.CurrentMapTile.Col = pLocation.Col Then
                AntExists = True
            End If
        Next

        Return AntExists
    End Function

    Friend Function GetActiveEnemyAntHillLocations(pEnemyAnyHillLocations As List(Of Location), Optional pReduceTimers As Boolean = True) As List(Of Location)
        Dim ActiveEnemyAntHillLocations As New List(Of Location)

        If pReduceTimers
            'Reduce all TTL values currently in the Enemy Ant Hill Memory list by 1
            Dim AllActiveEnemyHillKeys As New List(Of String)
            For Each ActiveEnemyHillKey As String In _EnemyAntHillMemoryTTL.Keys
                AllActiveEnemyHillKeys.Add(ActiveEnemyHillKey)
            Next
            For Each Key As String In AllActiveEnemyHillKeys
                _EnemyAntHillMemoryTTL(Key) = CInt(_EnemyAntHillMemoryTTL(Key)) - 1 
            Next
        End If

        'Check if the hills that current exist in the map already exist in the hash table of "remembered" enemy ant hill locations.
        'If the enemy ant hill already exists, reset its value to the max value. If it does not exist, add it to the hash table.
        Dim HillExists As Boolean
        For Each EnemyAntHillLocation As Location In pEnemyAnyHillLocations
            HillExists = False
            For Each ActiveEnemyHillKey As String In _EnemyAntHillMemoryTTL.Keys
                If GetLocationAsString(EnemyAntHillLocation) = ActiveEnemyHillKey
                    HillExists = True
                    _EnemyAntHillMemoryTTL(ActiveEnemyHillKey) = MAXENEMYANTHILLMEMORYTTL
                    Exit For
                End If
            Next
            If Not HillExists
                _EnemyAntHillMemoryTTL.Add(GetLocationAsString(EnemyAntHillLocation), MAXENEMYANTHILLMEMORYTTL)
            End If
        Next

        'Check if any remembered enemy ant hills have a TTL of 0 or less. If so, remove them from the list. We wont remember them.
        Dim RemoveKeys As New List(Of String)
        For Each ActiveEnemyHillKey As String In _EnemyAntHillMemoryTTL.Keys
            If CInt(_EnemyAntHillMemoryTTL(ActiveEnemyHillKey)) <= 0 Then
                RemoveKeys.Add(ActiveEnemyHillKey)
            End If
        Next
        For Each Key As String In RemoveKeys
            _EnemyAntHillMemoryTTL.Remove(Key)
        Next

        'Now create a list of all all active remember enemy ant hills from the list... this algorithm is kinda obtuse and non-elegant...
        Dim Split() As String
        For Each ActiveEnemyHillKey As String In _EnemyAntHillMemoryTTL.Keys
            Split = ActiveEnemyHillKey.Split("("c)
            Split = Split(1).Split(")"c)
            Split = Split(0).Split(","c)
            Dim ActiveLocation As New Location(CInt(Split(0)), CInt(Split(1)))
            ActiveEnemyAntHillLocations.Add(ActiveLocation)
        Next

        Return ActiveEnemyAntHillLocations
    End Function



#Region "Maintain Ant Hill List Logic"

    Private Sub UpdateColonyAntHills(pAntHillLocations As List(Of Location))
        'Add new ants to the list from the current list of colony ants
        For Each AntHillLocation As Location In pAntHillLocations
            If Not AntHillExists(AntHillLocation)
                AddNewAntHill(AntHillLocation)
            End If
        Next

        'Remove ants from the colony ant list that are not in the newest ant list (therefore they no longer exist on the map)
        Dim AntHillsToBeRemoved As New List(Of ColonyAntHill)
        For Each AntHill As ColonyAntHill In _ColonyAntHills
            If Not AntHillLocationExistsInColonyAntHills(AntHill, pAntHillLocations)
                AntHillsToBeRemoved.Add(AntHill)
            End If
        Next

        'Now actually remove the food items
        For Each AntHill As ColonyAntHill In AntHillsToBeRemoved
            RemoveAntHill(AntHill)
        Next
    End Sub

    Public Function AddNewAntHill(pLocation As Location) As ColonyAntHill
        Dim newColonyAntHill As ColonyAntHill = New ColonyAntHill(GetMapTile(pLocation.Row, pLocation.Col))
        _ColonyAntHills.Add(newColonyAntHill)
        Return newColonyAntHill
    End Function

    Public Function AntHillExists(pAntHillLocation As Location) As Boolean
        Dim Exists As Boolean = False
        For Each ExistingAntHill As ColonyAntHill In _ColonyAntHills
            If pAntHillLocation.Col = ExistingAntHill._AntHill.Col AndAlso pAntHillLocation.Row = ExistingAntHill._AntHill.Row
                Exists = True
                Exit For
            End If
        Next
        Return Exists
    End Function

    Public Function AntHillLocationExistsInColonyAntHills(pColonyAntHill As ColonyAntHill, pAntHillList As List(Of Location)) As Boolean
        Dim Exists As Boolean = False
        For Each AntHill As Location In pAntHillList
            If AntHill.Col = pColonyAntHill._AntHill.Col AndAlso AntHill.Row = pColonyAntHill._AntHill.Row
                Exists = True
                Exit For
            End If
        Next
        Return Exists
    End Function

    'Remove ColonyAnt from persistent list of ColonyAnts
    Public Sub RemoveAntHill(pColonyAntHill As ColonyAntHill)
        For Each AntHill As ColonyAntHill In _ColonyAntHills
            If AntHill.Equals(pColonyAntHill)
                _ColonyAntHills.Remove(AntHill)
                Exit For 'We found it and removed it, so stop looking!
            End If
        Next
    End Sub

#End Region



    Public Function GetLocationAsString(pLocation As Location) As String
        Return "(" & pLocation.Row & "," & pLocation.Col & ")"
    End Function


    #Region "Debugging Logic"
    Public Function xGetAnts() As List(Of ColonyAnt) Implements IColony.xGetAnts
        Return _ColonyAnts
    End Function
    #End Region

End Class
