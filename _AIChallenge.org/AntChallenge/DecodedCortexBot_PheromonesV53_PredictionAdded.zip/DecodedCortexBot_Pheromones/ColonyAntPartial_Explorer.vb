﻿Public Partial Class ColonyAnt

    Private Function GetExplorerMoveDirection() As Direction
        Dim MoveDirection As Direction
        'Walk away from MyAntHill until we get far enough away that we have no more guidance using
        '' the Strength hash table. Then, do a Random Walk.

        If MovementController.NearAlert
            If MovementController.NearMyAntHill
                MoveDirection = MovementController.GoDefendAntHill
            Else
                If MovementController.NearEnemyAnt
                    MoveDirection = MovementController.GoCombat
                Else
                    MoveDirection = MovementController.GoDefendAntHill  
                End If
                'MoveDirection = MovementController.GoTowardClosestEnemyAnt 'Alternative Action... Dont know which is better
            End If
            'If MovementController.NearEnemyAnt
            '    'MoveDirection = MovementController.GoTowardEnemyAnts
            '    MoveDirection = MovementController.GoDefendAntHill
            'Else
            '    MoveDirection = MovementController.GoTowardAlert
            'End If
        ElseIf MovementController.NearMyAntHill
            If MovementController.NearEnemyAnt
                'MoveDirection = MovementController.GoTowardEnemyAnts
                MoveDirection = MovementController.GoDefendAntHill
            ElseIf MovementController.NearFood
                MoveDirection = MovementController.GoTowardClosestFood
            Else
                MoveDirection = MovementController.GoExplore
            End If
        ElseIf MovementController.NearFood
            If MovementController.NearEnemyAnt
                MoveDirection = MovementController.GoCombat
            Else
                MoveDirection = MovementController.GoTowardClosestFood
            End If
            'MoveDirection = MovementController.GoTowardClosestFood
        ElseIf MovementController.NearEnemyAnt
            MoveDirection = MovementController.GoCombat
        ElseIf MovementController.NearEnemyAntHill
            If MovementController.NearEnemyAnt
                MoveDirection = MovementController.GoCombat
            Else
                MoveDirection = MovementController.GoTowardClosestEnemyAntHill
            End If
        Else
            MoveDirection = MovementController.GoExplore
        End If

                'If OnAlertStrengthTile() Then
                '    'If near an ALERT, go towards the alert. This will ALWAYS be priority.
                '    If OnEnemyAntStrengthTile() Then
                '        MoveDirection = ChooseHighestNonOccupiedAdjacentEnemyAntPheromoneStrengthDirection
                '    Else
                '        MoveDirection = ChooseHighestNonOccupiedAdjacentAlertStrengthDirection()
                '    End If
                'ElseIf OnMyAntHillStrengthTile
                '    If OnEnemyAntStrengthTile Then
                '        MoveDirection = ChooseHighestNonOccupiedAdjacentEnemyAntPheromoneStrengthDirection
                '    ElseIf OnFoodItemStrengthTile
                '        'We are near a food item, lets move towards it

                '        'Find the highest food strength value
                '        Dim HighestStrengthID As String = GetHighestAdjacentFoodStrengthValue()

                '        'Choose the adjacent tile that has the highest value for the found ID
                '        MoveDirection = ChooseHighestAdjacentFoodItemStrengthDirection(HighestStrengthID)

                '    Else
                '         'Find the lowest My Ant Pheromone Strength of all adjacent tiles
                '        Dim LowestMyAntPersistentPheromoneStrengthValue As Integer = GetLowestAdjacentMyAntPersistentPheromoneStrengthValue()

                '        If LowestMyAntPersistentPheromoneStrengthValue >= MapTile._MAXALLOWEDMYANTPERSISTENTPHEROMONESTRENGTH - 1
                '            'If we are in an area with maximum pheromone, walk in a random direction.
                '            MoveDirection = GetRandomWalkMoveDirection

                '        Else
                '            'We are still on our MyAntHill Strength mapping, determine our next move along the mapping
                '            MoveDirection = ChooseLowestAdjacentMyAntPersistentPheromoneStrengthDirection(LowestMyAntPersistentPheromoneStrengthValue)
                '        End If
                '    End If
                'ElseIf OnFoodItemStrengthTile() Then
                '    'We are near a food item, lets move towards it

                '    'Find the highest food strength value
                '    Dim HighestStrengthID As String = GetHighestAdjacentFoodStrengthValue()

                '    'Choose the adjacent tile that has the highest value for the found ID
                '    MoveDirection = ChooseHighestAdjacentFoodItemStrengthDirection(HighestStrengthID)
        
                'ElseIf OnEnemyAntStrengthTile() Then
                '    If OnMaxMyAntPersistentPheromoneTile
                '        'If near an enemy and on max my ant pheromone tile, go towards enemy
                '        MoveDirection = ChooseHighestNonOccupiedAdjacentEnemyAntPheromoneStrengthDirection()
                '    Else
                '        'If near an enemy and not on max my ant pheromone tile, go towards my pheromone
                '        MoveDirection = ChooseHighestNonOccupiedAdjacentMyAntPersistentPheromoneStrengthDirection()
                '    End If
                '    'If near an enemy, move towards my ant pheromone

                'ElseIf OnEnemyAntHillStrengthTile() Then
                '    'We are near an enemy ant hill, lets move towards it

                '    'Find the highest enemy ant hill strength value
                '    Dim HighestStrengthID As String = GetHighestAdjacentEnemyAntHillStrengthValue()

                '    'Choose the adjacent tile that has the highest value for the found ID
                '    'MoveDirection = ChooseHighestAdjacentEnemyAntHillStrengthDirection(HighestStrengthID)
                '    MoveDirection = ChooseHighestNonOccupiedAdjacentEnemyAntHillStrengthDirection(HighestStrengthID)

                'Else
            
                '     'Find the lowest My Ant Pheromone Strength of all adjacent tiles
                '    Dim LowestMyAntPersistentPheromoneStrengthValue As Integer = GetLowestAdjacentMyAntPersistentPheromoneStrengthValue()

                '    'If LowestMyAntPheromoneStrengthValue = 0 Then
                '    '    'We are at the edge of our MyAntHill Strength mapping, start random walking

                '    '    'This should never, ever happen, because all ants emit a pheromone, therefore it will NEVER be zero...
                '    '    MoveDirection = GetRandomWalkMoveDirection()


                '    If LowestMyAntPersistentPheromoneStrengthValue >= MapTile._MAXALLOWEDMYANTPERSISTENTPHEROMONESTRENGTH - 1
                '        'If we are in an area with maximum pheromone, walk in a random direction.
                '        MoveDirection = GetRandomWalkMoveDirection

                '    Else
                '        'We are still on our MyAntHill Strength mapping, determine our next move along the mapping
                '        MoveDirection = ChooseLowestAdjacentMyAntPersistentPheromoneStrengthDirection(LowestMyAntPersistentPheromoneStrengthValue)
                '    End If


                'End If
        
        Return MoveDirection
    End Function

        Private Function GetExplorerMoveDirection2() As Direction
        Dim MoveDirection As Direction
        'Walk away from MyAntHill until we get far enough away that we have no more guidance using
        '' the Strength hash table. Then, do a Random Walk.

        If MovementController.NearAlert
            If MovementController.NearMyAntHill
                MoveDirection = MovementController.GoDefendAntHill
            ElseIf MovementController.NearEnemyAntHill
                MoveDirection = MovementController.GoTowardClosestEnemyAntHill
            Else
                'MoveDirection = MovementController.GoCombat
                MoveDirection = MovementController.GoTowardClosestEnemyAnt 'Alternative Action... Dont know which is better
            End If
            'If MovementController.NearEnemyAnt
            '    'MoveDirection = MovementController.GoTowardEnemyAnts
            '    MoveDirection = MovementController.GoDefendAntHill
            'Else
            '    MoveDirection = MovementController.GoTowardAlert
            'End If
        ElseIf MovementController.NearMyAntHill
            If MovementController.NearEnemyAntHill
                MoveDirection = MovementController.GoTowardClosestEnemyAntHill
            ElseIf MovementController.NearEnemyAnt
                'MoveDirection = MovementController.GoTowardEnemyAnts
                MoveDirection = MovementController.GoDefendAntHill
            ElseIf MovementController.NearFood
                MoveDirection = MovementController.GoTowardClosestFood
            Else
                MoveDirection = MovementController.GoExplore
            End If
        ElseIf MovementController.NearFood
            MoveDirection = MovementController.GoTowardClosestFood
        'ElseIf MovementController.NearEnemyAnt
        '    MoveDirection = MovementController.GoCombat
        ElseIf MovementController.NearEnemyAntHill
            MoveDirection = MovementController.GoTowardClosestEnemyAntHill
        Else
            MoveDirection = MovementController.GoExplore
        End If

                'If OnAlertStrengthTile() Then
                '    'If near an ALERT, go towards the alert. This will ALWAYS be priority.
                '    If OnEnemyAntStrengthTile() Then
                '        MoveDirection = ChooseHighestNonOccupiedAdjacentEnemyAntPheromoneStrengthDirection
                '    Else
                '        MoveDirection = ChooseHighestNonOccupiedAdjacentAlertStrengthDirection()
                '    End If
                'ElseIf OnMyAntHillStrengthTile
                '    If OnEnemyAntStrengthTile Then
                '        MoveDirection = ChooseHighestNonOccupiedAdjacentEnemyAntPheromoneStrengthDirection
                '    ElseIf OnFoodItemStrengthTile
                '        'We are near a food item, lets move towards it

                '        'Find the highest food strength value
                '        Dim HighestStrengthID As String = GetHighestAdjacentFoodStrengthValue()

                '        'Choose the adjacent tile that has the highest value for the found ID
                '        MoveDirection = ChooseHighestAdjacentFoodItemStrengthDirection(HighestStrengthID)

                '    Else
                '         'Find the lowest My Ant Pheromone Strength of all adjacent tiles
                '        Dim LowestMyAntPersistentPheromoneStrengthValue As Integer = GetLowestAdjacentMyAntPersistentPheromoneStrengthValue()

                '        If LowestMyAntPersistentPheromoneStrengthValue >= MapTile._MAXALLOWEDMYANTPERSISTENTPHEROMONESTRENGTH - 1
                '            'If we are in an area with maximum pheromone, walk in a random direction.
                '            MoveDirection = GetRandomWalkMoveDirection

                '        Else
                '            'We are still on our MyAntHill Strength mapping, determine our next move along the mapping
                '            MoveDirection = ChooseLowestAdjacentMyAntPersistentPheromoneStrengthDirection(LowestMyAntPersistentPheromoneStrengthValue)
                '        End If
                '    End If
                'ElseIf OnFoodItemStrengthTile() Then
                '    'We are near a food item, lets move towards it

                '    'Find the highest food strength value
                '    Dim HighestStrengthID As String = GetHighestAdjacentFoodStrengthValue()

                '    'Choose the adjacent tile that has the highest value for the found ID
                '    MoveDirection = ChooseHighestAdjacentFoodItemStrengthDirection(HighestStrengthID)
        
                'ElseIf OnEnemyAntStrengthTile() Then
                '    If OnMaxMyAntPersistentPheromoneTile
                '        'If near an enemy and on max my ant pheromone tile, go towards enemy
                '        MoveDirection = ChooseHighestNonOccupiedAdjacentEnemyAntPheromoneStrengthDirection()
                '    Else
                '        'If near an enemy and not on max my ant pheromone tile, go towards my pheromone
                '        MoveDirection = ChooseHighestNonOccupiedAdjacentMyAntPersistentPheromoneStrengthDirection()
                '    End If
                '    'If near an enemy, move towards my ant pheromone

                'ElseIf OnEnemyAntHillStrengthTile() Then
                '    'We are near an enemy ant hill, lets move towards it

                '    'Find the highest enemy ant hill strength value
                '    Dim HighestStrengthID As String = GetHighestAdjacentEnemyAntHillStrengthValue()

                '    'Choose the adjacent tile that has the highest value for the found ID
                '    'MoveDirection = ChooseHighestAdjacentEnemyAntHillStrengthDirection(HighestStrengthID)
                '    MoveDirection = ChooseHighestNonOccupiedAdjacentEnemyAntHillStrengthDirection(HighestStrengthID)

                'Else
            
                '     'Find the lowest My Ant Pheromone Strength of all adjacent tiles
                '    Dim LowestMyAntPersistentPheromoneStrengthValue As Integer = GetLowestAdjacentMyAntPersistentPheromoneStrengthValue()

                '    'If LowestMyAntPheromoneStrengthValue = 0 Then
                '    '    'We are at the edge of our MyAntHill Strength mapping, start random walking

                '    '    'This should never, ever happen, because all ants emit a pheromone, therefore it will NEVER be zero...
                '    '    MoveDirection = GetRandomWalkMoveDirection()


                '    If LowestMyAntPersistentPheromoneStrengthValue >= MapTile._MAXALLOWEDMYANTPERSISTENTPHEROMONESTRENGTH - 1
                '        'If we are in an area with maximum pheromone, walk in a random direction.
                '        MoveDirection = GetRandomWalkMoveDirection

                '    Else
                '        'We are still on our MyAntHill Strength mapping, determine our next move along the mapping
                '        MoveDirection = ChooseLowestAdjacentMyAntPersistentPheromoneStrengthDirection(LowestMyAntPersistentPheromoneStrengthValue)
                '    End If


                'End If
        
        Return MoveDirection
    End Function


End Class
