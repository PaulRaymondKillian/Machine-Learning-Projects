﻿Option Strict On

Imports System.Collections.Generic

Public Class ColonyAntHill
    Public _AntHill As MapTile
    Public _LookoutTower As List(Of MapTile)
    Public _MAXALERTSTRENGTH As Integer = 15

    Public Sub New(pAntHillMapTile As MapTile)
        _AntHill = pAntHillMapTile
        _LookoutTower = New List(Of MapTile)
    End Sub

    Public Sub CalculateLookoutTowerLocations(pRadius As Integer)
        Dim N As MapTile = _AntHill
        Dim NE As MapTile = _AntHill
        Dim E As MapTile = _AntHill
        Dim SE As MapTile = _AntHill
        Dim S As MapTile = _AntHill
        Dim SW As MapTile = _AntHill
        Dim W As MapTile = _AntHill
        Dim NW As MapTile = _AntHill

        'Do the cardinal directions
        For i As Integer = 0 to pRadius
            N = N.LinkedTiles(Direction.n)
            S = S.LinkedTiles(Direction.s)
            E = E.LinkedTiles(Direction.e)
            W = W.LinkedTiles(Direction.w)
        Next

        'Do the more difficult directions...
        Dim Turn As Boolean = False
        For i As Integer = 0 to pRadius+1
            If Not Turn
                NE = NE.LinkedTiles(Direction.n)
                SE = SE.LinkedTiles(Direction.s)
                SW = SW.LinkedTiles(Direction.s)
                NW = NW.LinkedTiles(Direction.n)
                Turn = Not Turn
            Else
                NE = NE.LinkedTiles(Direction.e)
                SE = SE.LinkedTiles(Direction.e)
                SW = SW.LinkedTiles(Direction.w)
                NW = NW.LinkedTiles(Direction.w)
                Turn = Not Turn
            End If
        Next

        If N.Passable
            _LookoutTower.Add(N)
        End If
        If NE.Passable
            _LookoutTower.Add(NE)
        End If
        If E.Passable
            _LookoutTower.Add(E)
        End If
        If SE.Passable
            _LookoutTower.Add(SE)
        End If
        If S.Passable
            _LookoutTower.Add(S)
        End If
        If SW.Passable
            _LookoutTower.Add(SW)
        End If
        If W.Passable
            _LookoutTower.Add(W)
        End If
        If NW.Passable
            _LookoutTower.Add(NW)
        End If

        'Always consider The AntHill to be a lookout tower as well as the real lookout towers
        _LookoutTower.Add(_AntHill)

    End Sub

    Public Sub CheckLookoutTowers()
        For Each Tower As MapTile In _LookoutTower  
            If Tower.GetEnemyAntPheromoneStrength > 0
                Tower.SetAlertTileStrength(_MAXALERTSTRENGTH)
            End If
        Next
    End Sub

    Public Sub SetMAXALERTSTRENGTH(pNewMAXALERTSTRENGTH As Integer)
        _MAXALERTSTRENGTH = pNewMAXALERTSTRENGTH
    End Sub


End Class
