﻿Option Strict On

Imports System.Collections.Generic

Public Enum ColonyAntMission
    Explorer
    FoodGatherer
    AntHunter
    AntHillHunter
End Enum


Public Class ColonyAnt
    'Public CurrentLocation As Location
    Public CurrentMapTile As MapTile
    Public Mission As ColonyAntMission
    Public PreviousDirection As Direction
    Public StepCount As Integer
    Const STEPCOUNTTHRESHOLD As Integer = 10

    Private _Random As Random

    'Public Sub New(pCurrentLocation As Location)
    '    CurrentLocation = pCurrentLocation
    '    PreviousDirection = Direction.e
    'End Sub

    Public Sub New(pCurrentMapTile As MapTile, pRandom As Random)
        CurrentMapTile = pCurrentMapTile
        Mission = ColonyAntMission.Explorer
        PreviousDirection = Direction.w
        StepCount = 0
        _Random = pRandom
    End Sub

    Public Function GetAntMoveDirection As Direction
        Dim MoveDirection As Direction
        Select Case Mission
            Case ColonyAntMission.Explorer:
                MoveDirection = GetExplorerMoveDirection()
            Case ColonyAntMission.FoodGatherer:
                MoveDirection = GetFoodGathererDirection()
            Case ColonyAntMission.AntHunter:
                MsgBox("Warning! Not implemented yet")
            Case ColonyAntMission.AntHillHunter:
                MsgBox("Warning! Not implemented yet")

        End Select

        Return MoveDirection
    End Function

    Private Function GetExplorerMoveDirection() As Direction
        Dim MoveDirection As Direction
        'Walk in a straight line until either the forward unit is not-passable, or we have walked in a straight line enough times
        '' to warrant turning in a random direction 90 degrees (180 degrees if we have to).
        
        If StepCount < STEPCOUNTTHRESHOLD And CheckIfPassable(PreviousDirection) 'CurrentMapTile.LinkedTiles(PreviousDirection).Passable
            MoveDirection = PreviousDirection   'Keep moving in a straight line, so move forward in previous direction
        Else
            'Change directions 90 degrees randomly, if cannot turn left or right, turn around.
            'If _Random.Next Mod 100 < 50
            '    TempDirection = GetTurn90DegreeDirection(PreviousDirection, True)
            'Else
            '    TempDirection = GetTurn90DegreeDirection(PreviousDirection, False)
            'End If
            Dim ClockwiseTurn As Boolean = Convert.ToBoolean(_Random.Next Mod 1)
            MoveDirection = GetTurn90DegreeDirection(PreviousDirection, ClockwiseTurn)

            'Verify new direction is passable, If not, try other direction
            If Not CheckIfPassable(MoveDirection)
                MoveDirection = GetTurn90DegreeDirection(PreviousDirection, Not ClockwiseTurn)

                'Now, Verify is the New New direction is passable, if it isnt, then turn around from Previous direction
                If Not CheckIfPassable(MoveDirection)
                    MoveDirection = GetTurn180DegreeDirection(PreviousDirection)
                End If
            End If

        End If
        
        Return MoveDirection
    End Function

    Public Function CheckIfPassable(pDirection As Direction) As Boolean
        Return CurrentMapTile.LinkedTiles(pDirection).Passable
    End Function

    Private Function GetTurn90DegreeDirection(pCurrentDirection As Direction, pClockwiseTurn as Boolean) As Direction
        Dim NewDirection As Direction = PreviousDirection    'Set this to a value to prevent null ref 

        'I hate this algorithm... it is a stupid brute force. Need to fine a more elegant way to compute this.
        If pClockwiseTurn
            Select pCurrentDirection
                Case Direction.n:
                    NewDirection = Direction.e
                Case Direction.e:
                    NewDirection = Direction.s
                Case Direction.s:
                    NewDirection = Direction.w
                Case Direction.w:
                    NewDirection = Direction.n
            End Select
        Else
            Select pCurrentDirection
                Case Direction.n:
                    NewDirection = Direction.w
                Case Direction.e:
                    NewDirection = Direction.n
                Case Direction.s:
                    NewDirection = Direction.e
                Case Direction.w:
                    NewDirection = Direction.s
            End Select
        End If

        Return NewDirection
    End Function

    Private Function GetTurn180DegreeDirection(pCurrentDirection As Direction) As Direction
        Dim NewDirection As Direction = PreviousDirection 'Set this to a value to prevent null ref

        Select pCurrentDirection
            Case Direction.n:
                NewDirection = Direction.s
            Case Direction.e:
                NewDirection = Direction.w
            Case Direction.s:
                NewDirection = Direction.n
            Case Direction.w:
                NewDirection = Direction.e
            End Select

        Return NewDirection
    End Function

    Private Function GetFoodGathererDirection() As Direction
        Dim MoveDirection As Direction

        Return MoveDirection
    End Function

    Public Sub MoveAnt(pDirection As Direction)
        'Handle the step count to keep track of number of steps in a straight line
        If pDirection = PreviousDirection
            StepCount += 1                  'Increase step count because we walked in a straight line again
        Else
            StepCount = 0                   'Chagned direction, reset step count
            PreviousDirection = pDirection  'Set the new previous direction to keep track of steps in a straight line
        End If
        CurrentMapTile = CurrentMapTile.LinkedTiles(pDirection)
    End Sub

    Public Function GetAntLocation() As Location
        Return New Location(CurrentMapTile.Row, CurrentMapTile.Col)
    End Function

End Class
