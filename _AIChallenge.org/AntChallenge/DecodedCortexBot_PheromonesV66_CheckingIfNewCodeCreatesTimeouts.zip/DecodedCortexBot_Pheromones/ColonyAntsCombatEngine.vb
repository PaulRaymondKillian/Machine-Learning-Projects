﻿Option Strict On

Imports System.Collections.Generic
Imports System.Collections.Hashtable
Imports System.Collections

Public Interface IColonyAntsCombatEngine
    Sub ExecuteColonyAntsCombatEngine(pTurnCount As Integer, pColonyAnts As List(Of ColonyAnt), pColonyAntHills As List(Of ColonyAntHill), _
                                                pEnemyAntLocations As List(Of Location), pEnemyAntHillLocations As List(Of Location), _ 
                                                pArchivedEnemyAntHills As List(Of Location), pDestroyedEnemyAntHills As List(Of Location), _ 
                                                pMap As MapData)
End Interface

Public Class ColonyAntsCombatEngine : Implements IColonyAntsCombatEngine
    Public Sub New

    End Sub

    Public Sub ExecuteColonyAntsCombatEngine(pTurnCount As Integer, pColonyAnts As List(Of ColonyAnt), pColonyAntHills As List(Of ColonyAntHill), _
                                                pEnemyAntLocations As List(Of Location), pEnemyAntHillLocations As List(Of Location), _ 
                                                pArchivedEnemyAntHills As List(Of Location), pDestroyedEnemyAntHills As List(Of Location), _ 
                                                pMap As MapData) Implements IColonyAntsCombatEngine.ExecuteColonyAntsCombatEngine

        Dim MyCombatAnts As New List(Of ColonyAnt)
        Dim MyHillDefenseAnts As New List(Of ColonyAnt)
        Dim EnemyAntCombatAntListHash As New Hashtable

        'Gather a list of all of my ants that are near enemy ants. We can then ignore all other ants because they don't immediately matter
        For Each MyAnt As ColonyAnt In pColonyAnts
            For Each AdjTile As MapTile In MyAnt.CurrentMapTile.LinkedTiles
                If AdjTile.EnemyAntPheromoneStrengthHash.Count > 0
                    MyCombatAnts.Add(MyAnt)

                    'Find out of this ant is near my ant hill, if so, add them to the defense ant list as well
                    If MyAnt.CurrentMapTile.MyAntHillStrength > 0 Then
                        MyHillDefenseAnts.Add(MyAnt)
                    End If

                    Exit For 'We added the ant, exit the for loop and look at the other my ants
                End If
            Next
        Next
        
        'Create a list of my ants near each enemy ant, use "index" of pEnemyAntLocations as the key for the hash table
        For Index As Integer = 0 to pEnemyAntLocations.Count-1
            For Each MyAnt As ColonyAnt In MyCombatAnts
                For Each AdjTile As MapTile In MyAnt.CurrentMapTile.LinkedTiles
                    If CInt(AdjTile.EnemyAntPheromoneStrengthHash.Item(pMap.GetMapTile(pEnemyAntLocations(Index).Row, pEnemyAntLocations(Index).Col).ID)) > 0
                        If Not EnemyAntCombatAntListHash.ContainsKey(Index)
                            EnemyAntCombatAntListHash.Add(Index, New List(Of ColonyAnt))
                        End If
                        CType(EnemyAntCombatAntListHash.Item(Index), List(Of ColonyAnt)).Add(MyAnt)
                        Exit For'We added this ant for this enemy ant in the hash table, go on to the next ant
                    End If
                Next
            Next
        Next

        'Find the enemy ant who has the most my ants nearby
        'Dim HighestKey As String = ""
        'Dim HighestCount As Integer = Integer.MinValue
        'For Each Key As String In EnemyAntCombatAntListHash.Keys
        '    If CType(EnemyAntCombatAntListHash.Item(Key), List(Of ColonyAnt)).Count > HighestCount
        '        HighestKey = Key
        '        HighestCount = CType(EnemyAntCombatAntListHash.Item(Key), List(Of ColonyAnt)).Count
        '    End If
        'Next

    End Sub
End Class
